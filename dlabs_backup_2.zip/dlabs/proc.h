
#ifndef H_PROC
#define H_RROC


#include "stdio.h"
#include "stdlib.h"
#include "stdint.h"
#include "string.h"
#include "math.h"



#define TAG_WIDTH		0x100	//image width
#define TAG_LENGTH		0x101	//image length
#define TAG_BPS			0x102	//bits per sample
#define	TAG_COMPRESSION		0x103	//using type of compression
#define TAG_PH_INTERP		0x106	//using color model
#define TAG_FILL_ORDER		0x10A	//logical order of bits in bytes
#define TAG_STRIP_OFF		0x111	//offset for rows in bytes
#define TAG_ORIENTATION		0x112	//image orientation
#define TAG_SPP			0x115	//samples per pixel
#define TAG_RPS			0x116	//rows per strip
#define TAG_SBC			0x117	//bytes per rows
#define TAG_X_RES		0x11A	//number of pixels in rows in resolution units
#define TAG_Y_RES		0x11B	//number of pixels in columns in resolution units
#define TAG_PL_CONF		0x11C	//planar configuration
#define TAG_RES			0x128	//resolution of data
#define TAG_UNKNOWN_0		0x129	//
#define TAG_UNKNOWN_1		0x13D	//
#define TAG_UNKNOWN_2		0x13E	//
#define TAG_UNKNOWN_3		0x13F	//
#define TAG_EX_SAMPLES		0x152	//extra samples

#define NUM_OF_TAGS		20
#define NUM_OF_FIELD_TYPES	5

enum enum_field_types
{
	TYPE_BYTE = 1,
	TYPE_ASCII,
	TYPE_SHORT,		//16-bit (2 bytes)
	TYPE_LONG,		//32-bit (4 bytes)
	TYPE_RATIONAL  		//two longs (numerator and denominator)
};

struct st_tag_names
{
	uint16_t tag;
	char * name;
	char * description;
};

struct st_ifd_entry
{
	uint16_t tag;
	uint16_t field_type;
	uint32_t num_of_values;
	uint32_t offset;
};

struct st_image
{
	uint32_t w;
	uint32_t h;
	uint8_t * data;
	uint32_t size;
};

struct st_tiff_file
{
	char filename[128];
	uint32_t file_size;
	uint8_t * tiff_data;
	uint32_t data_offset;
	uint32_t data_size;
};


struct st_kernel
{
	uint32_t size;
	int32_t coeff;
	int32_t * data;
};



extern struct st_tag_names tag_names_list[NUM_OF_TAGS];
extern char * field_types_names[NUM_OF_FIELD_TYPES + 2];



void dprint(uint16_t value);
void dprint16(uint16_t value);
void dprint8(uint8_t value);
void dprint32(uint32_t value);
void dnl(void);
void dprint_ifd(struct st_ifd_entry * ifd_entry);
int32_t f_read_ifd(struct st_ifd_entry * ifd_entry, FILE *fd);
uint32_t f_from_offset32(FILE *fd, uint32_t offset);
uint16_t f_from_offset16(FILE * fd, uint32_t offset);
uint8_t f_from_offset8(FILE * fd, uint32_t offset);
void f_show_kernel(struct st_kernel * kernel);
int32_t f_open_tiff(char *filename, struct st_image * image, struct st_tiff_file * tiff);
int32_t f_save_tiff(char *filename, struct st_tiff_file * tiff, struct st_image * img);
int32_t f_save_tiff_2(char *filename, struct st_tiff_file * tiff, uint8_t * data_buffer, uint32_t data_buffer_size);
void f_convolution_2(uint8_t * src_data, uint8_t * res_data, uint32_t w, uint32_t h, int32_t * kernel_data, uint32_t kernel_size, int32_t kernel_coeff);
void f_close_tiff(struct st_tiff_file * tiff);
void f_close_image(struct st_image * img);
void f_close_kernel(struct st_kernel * kernel);
int32_t str_to_array(char * str, int32_t * array, uint32_t num_count, uint32_t array_size);
int32_t get_kernel_param(char * paramfile, struct st_kernel * kernel);
int32_t proc_image(char * filename, char * output, char * paramfile);

int32_t main_old(void);

#endif
