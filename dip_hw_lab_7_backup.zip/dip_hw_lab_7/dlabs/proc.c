
#include "proc.h"


struct st_tag_names tag_names_list[] = {
	{ TAG_WIDTH, "WIDTH", "image width" },
	{ TAG_LENGTH, "LENGTH", "image length" },
	{ TAG_BPS, "BPS", "bits per sample" },
	{ TAG_COMPRESSION, "TAG_COMPRESSION", "using type of compression" },
	{ TAG_PH_INTERP, "TAG_PH_INTERP", "using color model" },
	{ TAG_FILL_ORDER, "TAG_FILL_ORDER", "logical order of bits in bytes" },
	{ TAG_STRIP_OFF, "TAG_STRIP_OFF", "offset for rows in bytes" },
	{ TAG_ORIENTATION, "TAG_ORIENTATION", "image orientation" },
	{ TAG_SPP, "TAG_SPP", "samples per pixel" },
	{ TAG_RPS, "TAG_RPS", "rows per strip" },
	{ TAG_SBC, "TAG_SBC", "bytes per rows" },
	{ TAG_X_RES, "TAG_X_RES", "number of pixels in rows in resolution units" },
	{ TAG_Y_RES, "TAG_Y_RES", "number of pixels in columns in resolution units" },
	{ TAG_PL_CONF, "TAG_PL_CONF", "planar configuration" },
	{ TAG_RES, "TAG_RES", "resolution of data" },
	{ TAG_UNKNOWN_0, "TAG_UNKNOWN_0", "" },
	{ TAG_UNKNOWN_1, "TAG_UNKNOWN_1", "" },
	{ TAG_UNKNOWN_2, "TAG_UNKNOWN_2", "" },
	{ TAG_UNKNOWN_3,  "TAG_UNKNOWN_3", "" },
	{ TAG_EX_SAMPLES, "TAG_EX_SAMPLES", "extra samples" }
};


char * field_types_names[] = {
	NULL,
	"byte",
	"ascii",
	"short",
	"long",
	"rational",
	NULL
};


void dprint(uint16_t value)
{
	fprintf(stderr, "%d [0x%04X]", value, value);
}


void dprint16(uint16_t value)
{
	fprintf(stderr, "%d [0x%04X]", value, value);
}


void dprint8(uint8_t value)
{
	fprintf(stderr, "%d [0x%02X]", value, value);
}


void dprint32(uint32_t value)
{
	fprintf(stderr, "%d [0x%08X]", value, value);
}

void dnl(void)
{
	fprintf(stderr, "\n");
}


void dprint_ifd(struct st_ifd_entry * ifd_entry)
{
	fprintf(stderr, "tag:          \t\t"); dprint(ifd_entry->tag); dnl();
	fprintf(stderr, "field type:   \t\t");
	dprint(ifd_entry->field_type); fprintf(stderr, " (%s)\n", field_types_names[ifd_entry->field_type]);
	fprintf(stderr, "num of values:\t\t"); dprint32(ifd_entry->num_of_values); dnl();
	fprintf(stderr, "values offset:\t\t"); dprint32(ifd_entry->offset); dnl();
}

int32_t f_read_ifd(struct st_ifd_entry * ifd_entry, FILE *fd)
{
	uint16_t tmp;
	uint32_t value;
	int32_t result = 0;
	result += fread(&tmp, sizeof(uint16_t), 1, fd);
	ifd_entry->tag = tmp;
	result += fread(&tmp, sizeof(uint16_t), 1, fd);
	ifd_entry->field_type = tmp;
	result += fread(&value, sizeof(uint32_t), 1, fd);
	ifd_entry->num_of_values = value;
	result += fread(&value, sizeof(uint32_t), 1, fd);
	ifd_entry->offset = value;
	return result;
}

uint32_t f_from_offset32(FILE *fd, uint32_t offset)
{
	fpos_t old_pos;
	uint32_t value;

	fgetpos(fd, &old_pos);
	fseek(fd, offset, SEEK_SET);
	fread(&value, sizeof(uint32_t), 1, fd);
	fsetpos(fd, &old_pos);
	return value;
}

uint16_t f_from_offset16(FILE *fd, uint32_t offset)
{
	fpos_t old_pos;
	uint16_t value;

	fgetpos(fd, &old_pos);
	fseek(fd, offset, SEEK_SET);
	fread(&value, sizeof(uint16_t), 1, fd);
	fsetpos(fd, &old_pos);
	return value;
}

uint8_t f_from_offset8(FILE *fd, uint32_t offset)
{
	fpos_t old_pos;
	uint32_t value;

	fgetpos(fd, &old_pos);
	fseek(fd, offset, SEEK_SET);
	fread(&value, sizeof(uint8_t), 1, fd);
	fsetpos(fd, &old_pos);
	return value;
}



int32_t f_open_tiff(char *filename, struct st_image * image, struct st_tiff_file * tiff)
{

	FILE * fd;
	uint32_t buffer[512];
	uint32_t value;
	uint16_t tmp;
	struct st_ifd_entry ifd_entry;

	uint32_t data_offset;
	uint32_t data_size;

	uint32_t bytes_readed;

	if((fd = fopen(filename, "rb")) == NULL)
	{
		fprintf(stderr, "Error open image file: %s for read\n", filename);
		return -1;
	}


	fread(&tmp, sizeof(uint16_t), 1, fd);
	dprint(tmp); dnl();
	fread(&tmp, sizeof(uint16_t), 1, fd);
	dprint(tmp); dnl();
	fread(&value, sizeof(uint32_t), 1, fd);
	dprint32(value), dnl();

	fseek(fd, value, SEEK_SET);

	fread(&tmp, sizeof(uint16_t), 1, fd);
	fprintf(stderr, "Num of directory entries: \n");
	dprint(tmp); dnl();


	for(uint32_t i = 0; i < tmp; i++)
	{
		fprintf(stderr, "IFD NUM: %d\n", i);
//		f_read_ifd(&ifd_entry, fd);
		fread(&ifd_entry, sizeof(struct st_ifd_entry), 1, fd);
		dprint_ifd(&ifd_entry);

		for(uint32_t j = 0; j < NUM_OF_TAGS; j++)
		{
			if(tag_names_list[j].tag == ifd_entry.tag)
			{
				fprintf(stderr, "Tag name: %s\n", tag_names_list[j].name);
				fprintf(stderr, "Tag description: %s\n", tag_names_list[j].description);
			}
		}

		if(ifd_entry.tag == TAG_WIDTH)
		{
			image->w = ifd_entry.offset;
		} else if(ifd_entry.tag == TAG_LENGTH)
		{
			image->h = ifd_entry.offset;
		} else if(ifd_entry.tag == TAG_STRIP_OFF)
		{
			data_offset = ifd_entry.offset;
		} else if(ifd_entry.tag == TAG_SBC)
		{
			data_size = ifd_entry.offset;
		}

/*
		if(ifd_entry.tag == TAG_WIDTH || ifd_entry.tag == TAG_LENGTH)
		{
			uint32_t tmp0;
			tmp0 = f_from_offset32(fd, ifd_entry.offset);
			dprint32(tmp0); dnl();
		} else if(ifd_entry.tag == TAG_BPS || ifd_entry.tag == TAG_STRIP_OFF)
		{
			uint32_t tmp0 = f_from_offset32(fd, ifd_entry.offset);
			dprint32(tmp0); dnl();
		} else if(ifd_entry.tag == TAG_SBC)
		{
			uint32_t tmp0 = f_from_offset32(fd, ifd_entry.offset);
			dprint32(tmp0); dnl();
		}
*/
	}

	fread(&value, sizeof(uint32_t),1, fd);
	fprintf(stderr, "OFFSET OF NEXT IFD: "); dprint32(value); dnl();

	image->data = (uint8_t *)malloc(sizeof(uint8_t)*data_size);
	if(!image->data)
	{
		fprintf(stderr, "Memory allocation error (for image data) bytes required: %d\n", sizeof(uint8_t) * data_size);
		fclose(fd);
		image->size = 0;
		return -1;
	}

	fseek(fd, data_offset, SEEK_SET);

	bytes_readed = fread(image->data, sizeof(uint8_t), data_size, fd);
	image->size = data_size;

	if(data_size != bytes_readed)
	{
		fprintf(stderr, "Read file errors [bytes_readed != data_size] %d != %d\n", bytes_readed, data_size);
		fclose(fd);
		if(!image->data)
			free(image->data);
		image->size = 0;
		return -1;
	}
	else
	{
		fprintf(stderr, "Ok!... bytes_readed = %d = data_size = %d\n", bytes_readed, data_size);
	}

	if(tiff)
	{
		rewind(fd);
		fseek(fd, 0, SEEK_END);
		uint32_t file_size = ftell(fd);
		rewind(fd);
		tiff->file_size = file_size;
		strcpy(tiff->filename, filename);
		tiff->data_offset = data_offset;
		tiff->data_size = data_size;
		tiff->tiff_data = (uint8_t *)malloc(sizeof(uint8_t)*file_size);
		if(!tiff->tiff_data)
		{
			fprintf(stderr, "Memory allocation error (for tiff data) bytes required: %d\n", sizeof(uint8_t) * file_size);
			fclose(fd);
			tiff->data_offset = 0;
			tiff->tiff_data = 0;
			return -1;
		}
		if(tiff->tiff_data)
			fread(tiff->tiff_data, sizeof(uint8_t), file_size, fd);

	}


	fclose(fd);

	return 0;

}

int32_t f_save_tiff(char *filename, struct st_tiff_file * tiff, struct st_image * img)
{
	if(img != NULL)
	{
		if(img->data != NULL && tiff->tiff_data != NULL)
		{
			memcpy((void *)(&((tiff->tiff_data)[tiff->data_offset])), (void *)(img->data), tiff->data_size);
		}
	}

	FILE * fd;
	int32_t status;
	uint32_t bytes_writed;

	if((fd = fopen(filename, "wb")) == NULL)
	{
		fprintf(stderr, "Error open image file : %s for saving\n", filename);
		return -1;
	}


//	fd = fopen(filename, "wb");

	bytes_writed = fwrite(tiff->tiff_data, sizeof(uint8_t), tiff->file_size, fd);

	if(bytes_writed != tiff->file_size)
	{
		fprintf(stderr, "Save tiff errors [bytes_writed != file_size : %d != %d]\n", bytes_writed, tiff->file_size);
		status = -1;
	}
	else
	{
		fprintf(stderr, "Save tiff status:\nOk!... [bytes_writed = %d = file_size]\n", bytes_writed, tiff->file_size);
		status = 0;
	}
	fclose(fd);

	return status;

}


int32_t f_save_tiff_2(char *filename, struct st_tiff_file * tiff, uint8_t * data_buffer, uint32_t data_buffer_size)
{

	if(!data_buffer_size)
		data_buffer_size = tiff->data_size;


	struct st_image tmp_img;
	int32_t status;

	tmp_img.size = data_buffer_size;
	tmp_img.data = data_buffer;

	status =  f_save_tiff(filename, tiff, &tmp_img);

	return status;
}


void f_convolution_2(uint8_t * src_data, uint8_t * res_data, uint32_t w, uint32_t h, int32_t * kernel_data, uint32_t kernel_size, int32_t kernel_coeff)
{

	if(!kernel_coeff)
		kernel_coeff = 1;

	uint32_t half_size = kernel_size / 2;
	memcpy(res_data, src_data, sizeof(uint8_t) * w *  h);

	for(uint32_t y = half_size; y < h - half_size; ++y)
	{
		for(uint32_t x = half_size; x < w - half_size; ++x)
		{
			uint32_t * pk = kernel_data;
			uint8_t * ps = &(src_data[(y - half_size) * w + x - half_size]);
			int32_t conv_sum = 0;
			for(uint32_t v = 0; v < kernel_size; ++v)
			{
				for(uint32_t u = 0; u < kernel_size; u++)
				{
					conv_sum += ps[u] * pk[u];
				}
				pk += kernel_size;
				ps += w;
			}
			conv_sum = conv_sum / kernel_coeff;
			if(conv_sum > 255)
			{
				conv_sum = 255;
			} else if(conv_sum < 0)
			{
				conv_sum = 0;
			}
			res_data[y*w + x] = (uint8_t)(conv_sum);
		}
	}

}


void f_close_tiff(struct st_tiff_file * tiff)
{
	if(tiff->tiff_data)
		free(tiff->tiff_data);
	strcpy(tiff->filename, "");
	tiff->data_offset = 0;
	tiff->data_size = 0;
	tiff->file_size = 0;
}

void f_close_image(struct st_image * img)
{
	if(img->data)
		free(img->data);
	img->w = 0;
	img->h = 0;
	img->size = 0;
	img->data = NULL;
}

void f_close_kernel(struct st_kernel * kernel)
{
	if(kernel->data)
		free(kernel->data);
	kernel->size = 0;
	kernel->coeff = 0;
}

int32_t str_to_array(char * str, int32_t * array, uint32_t num_count, uint32_t array_size)
{
	char * p;
	uint32_t counter = 0;

	char tmp_buf[128] = { 0 };

	p = str;
	uint32_t k = 0;

	do
	{
		if(*p == ' ' || *p == '\t' || *p == ',' || *p == '\0' || *p == '\n')
		{
			tmp_buf[k] = '\0';
			k = 0;
			*p = '\0';
			array[counter] = (int32_t)(atoi(tmp_buf));
			counter++;
			if(counter >= num_count)
			{
				break;
			}
			p++;
			continue;
		}
		tmp_buf[k++] = *(p++);
	}
	while(*p != '\0' || *p != '\n');


	return counter;
/*
	p = strtok(str, " ,");
	sprintf(tmp_buf, "%s", p);
	array[counter] = (int32_t)(atoi(tmp_buf));
	counter++;

	fprintf(stderr, "array[%d] = %d\n", counter, array[counter]);

	do
	{

		fprintf(stderr, "array[%d] = %d\n", counter, array[counter]);

		if(p && counter < array_size)
		{
			sprintf(tmp_buf, "%s", p);
			array[counter] = (int32_t)(atoi(tmp_buf));
			counter++;
		}
		if(counter >= num_count)
			break;

	}
	while(p);

	return counter;
*/
}


uint32_t get_line(char * all_data, uint32_t offset, char * line_buffer)
{
	char * p = (char *)(&(all_data[offset]));
	uint32_t off = offset;
	while(*p != '\n')
	{
		off++;
		*(line_buffer++) = *(p++);
	}
	*line_buffer = '\0';
	return off + 1;
}


int32_t get_kernel_param(char * paramfile, struct st_kernel * kernel)
{
	FILE * fd;
	char tmp_buf[8192];
	uint32_t file_size;
	uint32_t bytes_readed;
	char line_buffer[512];
	char * line;

	uint32_t kernel_size = 0;
	int32_t kernel_coeff = 1;

	line = (char *)(line_buffer);

//	fd = fopen(paramfile, "rb");
	if((fd = fopen(paramfile, "rb")) == NULL)
	{
		fprintf(stderr, "Error open parameters file: %s\n", paramfile);
		return -1;
	}



	fseek(fd, 0, SEEK_END);
	file_size = ftell(fd);
	rewind(fd);

	bytes_readed = fread(tmp_buf, sizeof(char), file_size, fd);
	if(bytes_readed != file_size)
	{
		fclose(fd);
		fprintf(stderr, "Error reading params file: %s [bytes_readed != file_size ; %d != %d]\n", paramfile, bytes_readed, file_size);
		return -1;
	}
	else
	{
		fprintf(stderr, "Reading params file: %s status is\nOk!... [bytes_readed = %d = file_size = %d]\n", paramfile, bytes_readed, file_size);
	}

	uint32_t offset = 0;
//	line = strtok(tmp_buf, "\n");
	offset = get_line(tmp_buf, offset, line);

	uint32_t str_counter = 0;
	uint32_t flag_kernel_data = 0;
	if(!strcmp("[kernel]", line))
	{
		do
		{
			//line = strtok(NULL, "\n");
			line = (char *)(line_buffer);
			offset = get_line(tmp_buf, offset, line);

			if(strstr(line, "size"))
			{
				char * tmp_str;
				tmp_str = strstr(line, "=") + 1;
				kernel_size = (uint32_t)(atoi(tmp_str));
				kernel->data = (int32_t *)malloc(sizeof(int32_t) * kernel_size * kernel_size);
				if(!kernel->data)
				{
					fprintf(stderr, "Memory allocation error (for kernel data) bytes required: %d\n", sizeof(int32_t) * kernel_size * kernel_size);
					kernel->size = 0;
					kernel->coeff = 0;
					return -1;
				}
				kernel->size = kernel_size;
			} else if(strstr(line, "coeff"))
			{
				char * tmp_str;
				tmp_str = strstr(line, "=") + 1;
				kernel_coeff = (uint32_t)(atoi(tmp_str));
				kernel->coeff = kernel_coeff;
			} else if(strstr(line, "data:") || flag_kernel_data)
			{
				if(!flag_kernel_data)
				{
					flag_kernel_data = 1;
					continue;
				}
				int32_t tmp_array[512];
				uint32_t tmp_array_size = 512;
				int32_t num_in_str;
				num_in_str = str_to_array(line, tmp_array, kernel_size, tmp_array_size);
				if(num_in_str != kernel_size)
				{
					fprintf(stderr, "Error read kernel data from param file: %s\n", paramfile);
					fprintf(stderr, "Count of numbers in string is %d ( should be %d ) [ string counter: %d]\n", num_in_str, kernel_size, str_counter);
					if(kernel->data)
						free(kernel->data);
					kernel->data = NULL;
					kernel->size = 0;
					kernel->coeff = 0;
					return -1;
				}
				for(uint32_t i = 0; i < kernel_size; i++)
				{
					kernel->data[i + kernel_size * str_counter] = tmp_array[i];
				}
				str_counter++;
				if(str_counter >= kernel_size)
				{
					flag_kernel_data = 0;
					break;
				}
			} else
			{
				if(flag_kernel_data)
				{
					fprintf(stderr, "Error read kernel data from param file: %s\n", paramfile);
					fprintf(stderr, "Count of rows of kernel matrix is %d ( should be %d )\n", str_counter, kernel_size);
					if(kernel->data)
						free(kernel->data);
					kernel->data = NULL;
					kernel->size = 0;
					kernel->coeff = 0;
					return -1;
				}
			}
		}
		while(line);
	}

	return 0;

}

void f_show_kernel(struct st_kernel * kernel)
{
	fprintf(stderr, "Convolution kernel info:\n");
	fprintf(stderr, "\tsize = %d x %d\n", kernel->size, kernel->size);
	fprintf(stderr, "\tcoeff = %d\n", kernel->coeff);
	if(kernel->data)
	{
		fprintf(stderr, "\tdata = \n");
		for(uint32_t i = 0; i < kernel->size * kernel->size; i++)
		{
			if(i % kernel->size == 0 && i != 0)
				fprintf(stderr, "\n");
			fprintf(stderr, "%d\t", kernel->data[i]);
		}
	}
	fprintf(stderr, "\n");

}

int32_t proc_image(char * filename, char * output, char * paramfile)
{

	uint8_t * tmp_buf;
	uint32_t tmp_buf_size;

	int32_t * kernel_data;
	uint32_t kernel_size;
	int32_t kernel_coeff;

	struct st_image img;
	struct st_tiff_file tiff;
	struct st_kernel kernel;

	img.data = NULL;
	tiff.tiff_data = NULL;
	kernel.data = NULL;
	tmp_buf = NULL;
	kernel_data = NULL;
	tmp_buf_size = 0;
	kernel_size = 0;
	kernel_coeff = 0;

	int32_t status;

	char * default_filename = "data/baboon.tiff";
	char * default_output = "output.tiff";
	char * default_paramfile = "param.txt";

	if(!filename || !strcmp(filename, ""))
		filename = default_filename;
	if(!output || !strcmp(output, ""))
		output = default_output;
	if(!paramfile || !strcmp(paramfile, ""))
		paramfile = default_paramfile;

	fprintf(stderr, "Input image file: %s\n", filename);
	fprintf(stderr, "Output image file: %s\n", output);
	fprintf(stderr, "Config file: %s\n", paramfile);

	status = f_open_tiff(filename, &img, &tiff);
	if(status < 0)
	{
		fprintf(stderr, "In proccess image error: f_open_tiff() status = %d\n", status);
		f_close_image(&img);
		f_close_tiff(&tiff);
		return status;
	}

	status = get_kernel_param(paramfile, &kernel);
	if(status < 0)
	{
		fprintf(stderr, "In proccess image error: get_kernel_param() status = %d\n", status);
		f_close_image(&img);
		f_close_tiff(&tiff);
		f_close_kernel(&kernel);
		return status;
	}

	f_show_kernel(&kernel);

	tmp_buf = (uint8_t *)malloc(sizeof(uint8_t) * img.size);
	if(!tmp_buf)
	{
		fprintf(stderr, "In proccess image error: allocation memory error for tmp_buf [size: %d bytes]\n", sizeof(uint8_t) * img.size);
		f_close_image(&img);
		f_close_tiff(&tiff);
		f_close_kernel(&kernel);
		return -1;
	}
	tmp_buf_size = img.size;

	kernel_data = kernel.data;
	kernel_size = kernel.size;
	kernel_coeff = kernel.coeff;

	fprintf(stderr, "Convolution image with kernel...\n");

	f_convolution_2(img.data, tmp_buf, img.w, img.h, kernel_data, kernel_size, kernel_coeff);


	if(tmp_buf)
	{
		fprintf(stderr, "Save result in output file...\n");
		status = f_save_tiff_2(output, &tiff, tmp_buf, tmp_buf_size);
		if(status < 0)
		{
			fprintf(stderr, "In proccess image error: f_save_tiff_2() status = %d\n", status);
			f_close_image(&img);
			f_close_tiff(&tiff);
			f_close_kernel(&kernel);
			if(tmp_buf)
				free(tmp_buf);
			return -1;
		}
	}

	f_close_image(&img);
	f_close_tiff(&tiff);
	f_close_kernel(&kernel);

	if(tmp_buf)
		free(tmp_buf);

	return 0;
}



int32_t main_old(void)
{

	char *filename = "data/baboon.tiff";
	struct st_image img;
	struct st_tiff_file tiff;

	f_open_tiff(filename, &img, &tiff);

	fprintf(stderr, "Image size: %d\n", img.size);
	fprintf(stderr, "Image data addr: 0x%08X\n", img.data);

	if(img.data)
		for(uint32_t i = 0; i < 16; i++)
			fprintf(stderr, "\timg.data[%d] = %d\n", i, img.data[i]);

	if(tiff.tiff_data)
	{
		fprintf(stderr, "Tiff file name: %s\n", tiff.filename);
		fprintf(stderr, "Read status: Ok! [tiff data poiner = 0x%08X]\n", tiff.tiff_data);
	}
/*
	if(img.data && tiff.tiff_data)
	{

		for(uint32_t i = 0; i < img.size; i++)
		{
			img.data[i] = 255 - img.data[i];
		}
		f_save_tiff("invert_baboon.tiff", &tiff, &img);
	}
*/
	if(!img.data || !tiff.tiff_data)
	{

		f_close_image(&img);
		f_close_tiff(&tiff);

		return -1;
	}

	uint8_t * tmp_buf;
	uint32_t tmp_buf_size;
	tmp_buf = (uint8_t *)malloc(sizeof(uint8_t)*img.size);
	if(!tmp_buf)
	{
		fprintf(stderr, "Error malloc for tmp_buf [size: %d bytes]\n", sizeof(uint8_t)*img.size);
		f_close_image(&img);
		f_close_tiff(&tiff);

		return -1;
	}
	tmp_buf_size = img.size;

	struct st_kernel kernel;
	kernel.data = NULL;

	get_kernel_param("param.txt", &kernel);
	fprintf(stderr, "kernel.size = %d\n", kernel.size);
	fprintf(stderr, "kernel.coeff = %d\n", kernel.coeff);
	if(kernel.data)
	{
		fprintf(stderr, "kernel.data = \n");
		for(uint32_t i = 0; i < kernel.size * kernel.size; i++)
		{
			if(i % kernel.size == 0 && i != 0)
				fprintf(stderr, "\n");
			fprintf(stderr, "%d ", kernel.data[i]);
		}
	}
	fprintf(stderr, "\n");

	f_close_kernel(&kernel);

	uint8_t * src_data;
	uint8_t * res_data;
	uint32_t w, h, S, K, L, M;
	double sigma_param, h_param;
	src_data = img.data;
	res_data = tmp_buf;
	w = img.w;
	h = img.h;
	S = 7; K = 7;
	L = 3; M = 3;
	sigma_param = 0.25; h_param = 0.5;

/*
	nlm_filter(src_data, res_data, w, h, S, K, L, M, sigma_param, h_param);
	if(tmp_buf)
		f_save_tiff_2("nlm_filter_baboon.tiff", &tiff, tmp_buf, tmp_buf_size);
*/

/*
	uint32_t kernel_size = 3;
	int32_t kernel_coeff = 9;
	int32_t kernel_data[ 3 * 3 ] = {
		1, 1, 1,
		1, 1, 1,
		1, 1, 1
	};

	f_convolution_2(img.data, tmp_buf, img.w, img.h, kernel_data, kernel_size, kernel_coeff);

	if(tmp_buf)
		f_save_tiff_2("convolution_baboon.tiff", &tiff, tmp_buf, tmp_buf_size);
*/


/*	if(tmp_buf)
	{
		memcpy((void *)(img.data), (void *)(tmp_buf), tmp_buf_size);
		free(tmp_buf);
	}

	f_save_tiff("convolution_baboon.tiff", &tiff, &img);
*/

	if(tmp_buf)
		free(tmp_buf);

	f_close_image(&img);
	f_close_tiff(&tiff);

	return 0;

}




void generate_normal_noise(int8_t * noise, uint32_t buffer_size, double mean, double std)
{
	srand(time(NULL));

	double epsilon = 0.000000000f;
	double x, y;
	double z, z0, z1;
	double s;

	for(uint32_t i = 0; i < buffer_size; i++)
	{
		x = (double)(rand() / RAND_MAX) * 2.0 - 1.0;
		y = (double)(rand() / RAND_MAX) * 2.0 - 1.0;
		s = x * x  + y * y;
		if(abs(s - 0.0 - epsilon) > 0.0 && abs(s - 1.0) <= epsilon)
		{
			z0 = x * sqrt(-2.0f * log(s) / s);
			z1 = y * sqrt(-2.0f * log(s) / s);
			z = mean + z0 * std;
			noise[i] = (int8_t)(z);
		}
		else
		{
			i--;
			continue;
		}
	}

}


void debug_print(struct st_image * img, uint32_t row_len, uint32_t columns_num)
{

	for(uint32_t j = 0; j < columns_num; j++)
	{
		for(uint32_t i = 0; i < row_len; i++)
		{
			fprintf(stderr, "%03d ", img->data[j * img->w + i]);
		}
	fprintf(stderr, "\n");
	}

}

int32_t compare_func(uint8_t * i, uint8_t * j)
{
	return *i - *j;
}

void f_rang_filter(uint8_t * src_data, uint8_t * res_data, uint32_t w, uint32_t h, int32_t * kernel_data, uint32_t kernel_size, int32_t kernel_coeff)
{

	if(!kernel_coeff)
		kernel_coeff = 1;

	uint32_t half_size = kernel_size / 2;
	memcpy(res_data, src_data, sizeof(uint8_t) * w *  h);

	uint32_t sort_buf_size;
	uint8_t * sort_buf;

	sort_buf = NULL;
	sort_buf_size = 0;

	for(uint32_t i = 0; i < kernel_size * kernel_size; i++)
	{
		sort_buf_size += kernel_data[i];
	}

	sort_buf = (uint8_t *)malloc(sizeof(uint8_t) * sort_buf_size);

	if(!sort_buf)
	{
		fprintf(stderr, "In f_rang_filter allocation memory error: requested size %d bytes\n", sizeof(uint8_t) * sort_buf_size);
		return;
	}

#ifdef DEBUG_RF
	uint32_t debug_counter;
	uint32_t debug_counter_limit;
	debug_counter = 0;
	debug_counter_limit = 5;
#endif

	for(uint32_t y = half_size; y < h - half_size; ++y)
	{
		for(uint32_t x = half_size; x < w - half_size; ++x)
		{
			uint32_t * pk = kernel_data;
			uint8_t * ps = &(src_data[(y - half_size) * w + x - half_size]);
			int32_t conv_sum = 0;
			uint32_t sort_buf_counter = 0;

			for(uint32_t v = 0; v < kernel_size; ++v)
			{
				for(uint32_t u = 0; u < kernel_size; u++)
				{
					if(pk[u] == 0)
					{
						continue;
					} else if(pk[u] > 0)
					{
						for(uint32_t i = 0; i < pk[u]; i++)
						{
							sort_buf[sort_buf_counter++] = ps[u];
						}
					}
					//conv_sum += ps[u] * pk[u];
				}
				pk += kernel_size;
				ps += w;
			}
			qsort(sort_buf, sort_buf_size, sizeof(uint8_t), (int32_t (*)(uint8_t *, uint8_t *)) compare_func);

		#ifdef DEBUG_RF
			fprintf(stderr, "debug_counter = %d [debug_counter_limit = %d]\n", debug_counter, debug_counter_limit);
			fprintf(stderr, "Sorted array [sort_buf_size = %d ; sort_buf_counter = %d]:\n", sort_buf_size, sort_buf_counter);
			for(uint32_t i = 0; i < sort_buf_size; i++)
			{
				fprintf(stderr, "%d ", sort_buf[i]);
			}
			fprintf(stderr, "\nMedian value is %d\n", sort_buf[sort_buf_size/2]);
			debug_counter++;
			if(debug_counter >= debug_counter_limit)
			{
				if(sort_buf)
					free(sort_buf);
				return;
			}
		#endif

			/*
			conv_sum = conv_sum / kernel_coeff;
			if(conv_sum > 255)
			{
				conv_sum = 255;
			} else if(conv_sum < 0)
			{
				conv_sum = 0;
			}
			res_data[y*w + x] = (uint8_t)(conv_sum);
			*/
			res_data[y * w + x] = sort_buf[sort_buf_size / 2];
		}
	}

	if(sort_buf)
		free(sort_buf);

}


double block_affinity_func(uint8_t * src_data, uint32_t w, uint32_t h, uint32_t M, uint32_t L, double sigma_param, double h_param, uint32_t r, uint32_t c, uint32_t i, uint32_t j)
{

	uint32_t half_size_x = M/2;
	uint32_t half_size_y = L/2;

	double res;

	res = 0.0f;

	for(uint32_t y = 0; y < L; ++y)
	{
		for(uint32_t x = 0; x < M; ++x)
		{
			uint8_t * p_block_1 = (uint8_t *)(&(src_data[(r - half_size_y + y)*w + c - half_size_x + x]));
			uint8_t * p_block_2 = (uint8_t *)(&(src_data[(r + i - half_size_y + y)*w + c + j - half_size_x + x]));
			int32_t I1 = (int32_t)(*p_block_1);
			int32_t I2 = (int32_t)(*p_block_2);
		#ifdef DEBUG_NLM
			fprintf(stderr, "I1 = %d; I2 = %d\n", I1, I2);
		#endif

			int32_t k = (int32_t)(y) - (int32_t)(half_size_y);
			int32_t n = (int32_t)(x) - (int32_t)(half_size_x);
			res += (I1 - I2)*(I1 - I2)*exp(-(k * k + n * n)/(2.0 * sigma_param * sigma_param));
		}
	}

#ifdef DEBUG_NLM
	fprintf(stderr, "block_affinity_func(): s = %.2f; h = %.2f:\n", sigma_param, h_param);
	fprintf(stderr, "res = %f\n", res);

	res = exp(-res/(h_param * h_param));

	fprintf(stderr, "res = %f\n", res);
#else
	res = exp(-res/(h_param * h_param));
#endif

	return res;

}

void nlm_filter(uint8_t * src_data, uint8_t * res_data, uint32_t w, uint32_t h, uint32_t S, uint32_t K, uint32_t L, uint32_t M, double sigma_param, double h_param)
{

	uint32_t half_size_x = S / 2;
	uint32_t half_size_y = K / 2;
	uint32_t half_size_bx = L / 2;
	uint32_t half_size_by = M / 2;
	memcpy(res_data, src_data, sizeof(uint8_t) * w *  h);

	for(uint32_t y = half_size_y + half_size_by; y < h - half_size_y - half_size_by; ++y)
	{

		for(uint32_t x = half_size_x + half_size_bx; x < w - half_size_x - half_size_bx; ++x)
		{

		#ifdef DEBUG_NLM
			fprintf(stderr, "x = %d; y = %d [data: %d]\n", x, y, src_data[y * w + x]);
		#endif
			double d11 = 0.0;
			double d00 = 0.0;
			int32_t rs;

			for(uint32_t v = y - half_size_y; v < y + half_size_y; ++v)
			{
				for(uint32_t u = x - half_size_x; u < x + half_size_x; ++u)
				{


					double d0;
					double d1;
					d0 = block_affinity_func(src_data, w, h, M, L, sigma_param, h_param, y, x, v - y, u - x);
					d1 = (double)(src_data[v * w + u])*d0;
					d00 += d0;
					d11 += d1;
				#ifdef DEBUG_NLM
					fprintf(stderr, "u = %d; v = %d [data: %d] [d0: %f] [d1: %f]\n", u, v, src_data[v * w + u], d0, d1);
				#endif

				}
			}

			rs = (int32_t)(d11 / d00);
		#ifdef DEBUG_NLM
			fprintf(stderr, "rs = %d; d11 = %f; d00 = %f\n", rs, d11, d00);
		#endif
			if(rs > 255)
			{
				rs = 255;
			} else if(rs < 0)
			{
				rs = 0;
			}

			res_data[y * w + x] = (uint8_t)(rs);
		#ifdef DEBUG_NLM
			break;
		#endif
		}
	#ifdef DEBUG_NLM
		break;
	#endif
	}

}





int32_t debug_main(int32_t argc, char **argv)
{

	char *filename = "data/noise_baboon.tiff";
	struct st_image img;
	struct st_tiff_file tiff;

	f_open_tiff(filename, &img, &tiff);

	fprintf(stderr, "Image size: %d\n", img.size);
	fprintf(stderr, "Image data addr: 0x%08X\n", img.data);


	if(tiff.tiff_data)
	{
		fprintf(stderr, "Tiff file name: %s\n", tiff.filename);
		fprintf(stderr, "Read status: Ok! [tiff data poiner = 0x%08X]\n", tiff.tiff_data);
	}

	if(!img.data || !tiff.tiff_data)
	{

		f_close_image(&img);
		f_close_tiff(&tiff);

		return -1;
	}



	uint8_t * tmp_buf;
	uint32_t tmp_buf_size;
	tmp_buf = (uint8_t *)malloc(sizeof(uint8_t)*img.size);
	if(!tmp_buf)
	{
		fprintf(stderr, "Error malloc for tmp_buf [size: %d bytes]\n", sizeof(uint8_t)*img.size);
		f_close_image(&img);
		f_close_tiff(&tiff);

		return -1;
	}
	tmp_buf_size = img.size;

	uint32_t kernel_size = 3;
	int32_t kernel_coeff = 1;
	int32_t kernel_data[ 3 * 3 ] = {
		0, 2, 0,
		2, 1, 2,
		0, 2, 0
	};

	f_rang_filter(img.data, tmp_buf, img.w, img.h, kernel_data, kernel_size, kernel_coeff);

	if(tmp_buf)
		f_save_tiff_2("rang_filter_noise_baboon.tiff", &tiff, tmp_buf, tmp_buf_size);


	if(tmp_buf)
		free(tmp_buf);

	f_close_image(&img);
	f_close_tiff(&tiff);

	return 0;



	uint8_t * src_data;
	uint8_t * res_data;
	uint32_t w, h, S, K, L, M;
	double sigma_param, h_param;
	src_data = img.data;
	res_data = tmp_buf;
	w = img.w;
	h = img.h;
	S = 7; K = 7;
	L = 3; M = 3;
	sigma_param = 1.0f; h_param = 1.0f;

	debug_print(&img, 25, 10);


	nlm_filter(src_data, res_data, w, h, S, K, L, M, sigma_param, h_param);
	if(tmp_buf)
		f_save_tiff_2("nlm_filter_noise_baboon.tiff", &tiff, tmp_buf, tmp_buf_size);

	debug_print(&img, 25, 10);


	if(tmp_buf)
		free(tmp_buf);

	f_close_image(&img);
	f_close_tiff(&tiff);

	return 0;

}

int32_t open_template_tiff(uint32_t start_row, char * bg_fn, char * in_fn_1, char * in_fn_2, char * out_fn)
{

	char background_filename[128] = { 0 };
	char filename_1[128] = { 0 };
	char filename_2[128] = { 0 };
	char output_filename[128] = { 0 };

	struct st_image background;
	struct st_tiff_file background_tiff;

	struct st_image img1;
	struct st_image img2;
	struct st_tiff_file tiff1;
	struct st_tiff_file tiff2;


	uint8_t * tmp_buf;
	uint32_t tmp_buf_size;

	sprintf(background_filename, "%s", bg_fn);
	sprintf(filename_1, "%s", in_fn_1);
	sprintf(filename_2, "%s", in_fn_2);
	sprintf(output_filename, "%s", out_fn);


	f_open_tiff(background_filename, &background, &background_tiff);

	if(!background.data || !background_tiff.tiff_data)
	{
		f_close_image(&background);
		f_close_tiff(&background_tiff);
		return -1;
	}
	else
	{
		fprintf(stderr, "[background] Status of opening background image (filename .tiff is %s) is ok!...\n", background_filename);
	}

	f_open_tiff(filename_1, &img1, &tiff1);

	if(!img1.data || !tiff1.tiff_data)
	{
		f_close_image(&background);
		f_close_tiff(&background_tiff);
		f_close_image(&img1);
		f_close_tiff(&tiff1);
		return -1;
	}
	else
	{
		fprintf(stderr, "[background] Status of opening first image ( filename .tiff is %s) is ok!...\n", filename_1);
	}


	f_open_tiff(filename_2, &img2, &tiff2);

	if(!img2.data || !tiff2.tiff_data)
	{
		f_close_image(&background);
		f_close_tiff(&background_tiff);
		f_close_image(&img1);
		f_close_tiff(&tiff1);
		f_close_image(&img2);
		f_close_tiff(&tiff2);
		return -1;
	}
	else
	{
		fprintf(stderr, "[background] Status of opening second image ( filename .tiff is %s) is ok!...\n", filename_2);
	}


	tmp_buf = (uint8_t *)malloc(sizeof(uint8_t)*background.size);

	if(!tmp_buf)
	{
		fprintf(stderr, "[background] Error malloc for tmp_buf [size: %d bytes]\n", sizeof(uint8_t)*background.size);
		f_close_image(&background);
		f_close_tiff(&background_tiff);
		f_close_image(&img1);
		f_close_tiff(&tiff1);
		f_close_image(&img2);
		f_close_tiff(&tiff2);
		return -1;
	}

	tmp_buf_size = background.size;
	memcpy(tmp_buf, background.data, background.size);


	uint32_t w_1 = img1.w;
	uint32_t h_1 = img1.h;
	uint32_t w_2 = img2.w;
	uint32_t h_2 = img2.h;
	uint32_t w = w_1;
	uint32_t h = h_1;
	uint32_t w_b = background.w;
	uint32_t h_b = background.h;

	for(uint32_t i = 0 ; i < h ; i++)
	{
		for(uint32_t j = 0 ; j < w ; j++)
		{
			tmp_buf[i * w_b + j + start_row * w_b] = img1.data[i * h + j];
			tmp_buf[i * w_b + j + w + start_row * w_b] = img2.data[i * h + j];
		}
	}

	if(tmp_buf)
	{
		f_save_tiff_2(output_filename, &background_tiff, tmp_buf, tmp_buf_size);
	}

	if(tmp_buf)
	{
		free(tmp_buf);
	}


	f_close_image(&background);
	f_close_tiff(&background_tiff);
	f_close_image(&img1);
	f_close_tiff(&tiff1);
	f_close_image(&img2);
	f_close_tiff(&tiff2);



	return 0;

}


int32_t nlm_main(char * input_fn, char * output_fn, double sigma_param_, double h_param_, uint32_t S_, uint32_t K_, uint32_t L_, uint32_t M_)
{

//	char * filename = "data/noise_baboon.tiff";
	char filename[256] = { 0 };
	char output_filename[256] = { 0 };
	struct st_image img;
	struct st_tiff_file tiff;

	sprintf(filename, "%s", input_fn);
	sprintf(output_filename, "%s", output_fn);

	f_open_tiff(filename, &img, &tiff);

	fprintf(stderr, "Image size: %d\n", img.size);
	fprintf(stderr, "Image data addr: 0x%08X\n", img.data);


	if(tiff.tiff_data)
	{
		fprintf(stderr, "Tiff file name: %s\n", tiff.filename);
		fprintf(stderr, "Read status: Ok! [tiff data poiner = 0x%08X]\n", tiff.tiff_data);
	}

	if(!img.data || !tiff.tiff_data)
	{

		f_close_image(&img);
		f_close_tiff(&tiff);

		return -1;
	}



	uint8_t * tmp_buf;
	uint32_t tmp_buf_size;
	tmp_buf = (uint8_t *)malloc(sizeof(uint8_t)*img.size);
	if(!tmp_buf)
	{
		fprintf(stderr, "Error malloc for tmp_buf [size: %d bytes]\n", sizeof(uint8_t)*img.size);
		f_close_image(&img);
		f_close_tiff(&tiff);

		return -1;
	}
	tmp_buf_size = img.size;


	uint8_t * src_data;
	uint8_t * res_data;
	uint32_t w, h, S, K, L, M;
	double sigma_param, h_param;
	src_data = img.data;
	res_data = tmp_buf;
	w = img.w;
	h = img.h;
//	S = 7; K = 7;
//	L = 3; M = 3;
//	sigma_param = 1.0f; h_param = 100.0f;
	sigma_param = sigma_param_;
	h_param = h_param_;
	S = S_;
	K = K_;
	L = L_;
	M = M_;

//	debug_print(&img, 25, 10);


	nlm_filter(src_data, res_data, w, h, S, K, L, M, sigma_param, h_param);

	if(tmp_buf)
	{
//		f_save_tiff_2("nlm_output/baboon_0.tiff", &tiff, tmp_buf, tmp_buf_size);
		f_save_tiff_2(output_filename, &tiff, tmp_buf, tmp_buf_size);
	}

//	debug_print(&img, 25, 10);


	if(tmp_buf)
		free(tmp_buf);

	f_close_image(&img);
	f_close_tiff(&tiff);

	return 0;

}

int32_t combine_images(char * bg_fn, char * out_fn, char * in_fn_1, char * in_fn_2, char * in_fn_3, char * in_fn_4, uint32_t * row_offset)
{

	int32_t return_code;

	uint32_t start_row;

	char filename_1[128] = { 0 };
	char filename_2[128] = { 0 };
	char filename_3[128] = { 0 };
	char filename_4[128] = { 0 };
	char background_filename[128] = { 0 };
	char output_filename[128] = { 0 };

	if(!bg_fn)
	{
		sprintf(background_filename, "%s", "data/template.tiff");
		fprintf(stderr, "[main.c:combine_images()]: bg_fn = %08X (is NULL)\nUse default background file: %s\n", bg_fn, "data/template.tiff");
	}
	else
	{
		sprintf(background_filename, "%s", bg_fn);
		fprintf(stderr, "[main.c:combine_images()]: bg_fn = %08X\nUse backgroundfile: %s\n", bg_fn, background_filename);
	}
	if(!out_fn)
	{
		sprintf(output_filename, "%s", "combined_image.tiff");
		fprintf(stderr, "[main.c:combine_images()]: out_fn = %08X (is NULL)\nUse default output file: %s\n", out_fn, "combined_image.tiff");
	}
	else
	{
		sprintf(output_filename, "%s", out_fn);
		fprintf(stderr, "[main.c:combine_images()]: out_fn = %08X\nUse output file: %s\n", out_fn, output_filename);
	}



	if(!in_fn_1 || !in_fn_2)
	{
		return_code = 0;
		fprintf(stderr, "[main.c:combine_images()]:\nImage 1 = NONE [ptr = %08X (is NULL)]\nImage 2 = NONE [ptr = %08X (is NULL)]\n", in_fn_1, in_fn_2);
		fprintf(stderr, "[main.c:combine_images()] Return with return value : return_code = %d\n", return_code);
		return return_code;
	}

	start_row = 0;
	sprintf(filename_1, "%s", in_fn_1);
	sprintf(filename_2, "%s", in_fn_2);
	return_code = open_template_tiff(start_row, background_filename, filename_1, filename_2, output_filename);

	fprintf(stderr, "[main.c:combine_images()]:\nImage 1 = %s [ptr = %08X]\nImage 2 = %s [ptr = %08X]\n", filename_1, in_fn_1, filename_2, in_fn_2);
	fprintf(stderr, "start_row = %d\n", start_row);

	if(return_code < 0)
	{
		fprintf(stderr, "[main.c:combine_images()] open_template_tiff() function return_code = %d\n", return_code);
		fprintf(stderr, "[main.c:combine_images()]\n\tstart_row = %d\n\tbackground filename = %s\n\t", start_row, background_filename);
		fprintf(stderr, "filename 1 = %s\n\tfilename 2 = %s\n\toutput filename = %s\n", filename_1, filename_2, output_filename);
		fprintf(stderr, "[main.c:combine_images()] Exit with return code : return_code = %d\n", return_code);
		return return_code;
	}



	if(!in_fn_3 && !in_fn_4)
	{
		fprintf(stderr, "[main.c:combine_images()]:\nImage 3 = NONE [ptr = %08X (is NULL)]\nImage 4 = NONE [ptr = %08X (is NULL)]\n", in_fn_3, in_fn_4);
		fprintf(stderr, "[main.c:combine_images()] Return with return value : return_code = %d\n", return_code);
		return return_code;

	} else if(!in_fn_3 && in_fn_4)
	{
		fprintf(stderr, "[main.c:combine_images()]:\nImage 3 = NONE [ptr = %08X (is NULL)]\nImage 4 = %s [ptr = %08X]\n", in_fn_3, in_fn_4, in_fn_4);
		fprintf(stderr, "[main.c:combine_images()]: Use Image 4 instead Image 3:\n");
		in_fn_3 = in_fn_4;


	} else if(in_fn_3 && !in_fn_4)
	{
		fprintf(stderr, "[main.c:combine_images()]:\nImage 3 = %s [ptr = %08X]\nImage 4 = NONE [ptr = %08X (is NULL)]\n", in_fn_3, in_fn_3, in_fn_4);
		fprintf(stderr, "[main.c:combine_images()]: Use Image 3 instead Image 4:\n");
		in_fn_4 = in_fn_3;

	}


	sprintf(filename_3, "%s", in_fn_3);
	sprintf(filename_4, "%s", in_fn_4);
	fprintf(stderr, "[main.c:combine_images()]:\nImage 3 = NONE [ptr = %08X (is NULL)]\nImage 4 = %s [ptr = %08X]\n", filename_3, in_fn_3, filename_4, in_fn_4);


	if(!row_offset)
	{
		start_row = 512;
		fprintf(stderr, "row_offset = %08X (is NULL)\n", row_offset);
		fprintf(stderr, "start_row = %d (using default value : 512)\n", start_row);

	}
	else
	{
		start_row = *row_offset;
		fprintf(stderr, "row_offset = %08X (not NULL) [value = %d]\n", row_offset, *row_offset);
		fprintf(stderr, "start_row = %d\n", start_row);

	}

	return_code = open_template_tiff(start_row, output_filename, filename_3, filename_4, output_filename);
	if(return_code < 0)
	{
		fprintf(stderr, "[main.c:combine_images()] open_template_tiff() function return_code = %d\n", return_code);
		fprintf(stderr, "[main.c:combine_images()]\n\tstart_row = %d\n\tbackground filename = %s\n\t", start_row, output_filename);
		fprintf(stderr, "filename 3 = %s\n\tfilename 4 = %s\n\toutput filename = %s\n", filename_3, filename_4, output_filename);
		fprintf(stderr, "[main.c:combine_images()] Exit with return code : return_code = %d\n", return_code);
		return return_code;
	}

	return return_code;
}


int32_t combine_main(int32_t argc, char **argv)
{

	char * p;

	char filename_1[128] = { 0 };
	char filename_2[128] = { 0 };
	char filename_3[128] = { 0 };
	char filename_4[128] = { 0 };
	char background_filename[128] = { 0 };
	char output_filename[128] = { 0 };

	int32_t result;

	char * bg_fn = NULL;
	char * out_fn = NULL;
	char * in_fn_1 = NULL;
	char * in_fn_2 = NULL;
	char * in_fn_3 = NULL;
	char * in_fn_4 = NULL;
	uint32_t * row_offset = NULL;
	uint32_t start_row;

	for(uint32_t i = 1 ; i < argc ; i++)
	{
		if(( p = strstr(argv[i], "--f1=")) != NULL)
		{
			p = strstr(argv[i], "=") + 1;
			sprintf(filename_1, "%s", p);
			in_fn_1 = filename_1;

		} else if(( p = strstr(argv[i], "--f2=")) != NULL)
		{
			p = strstr(argv[i], "=") + 1;
			sprintf(filename_2, "%s", p);
			in_fn_2 = filename_2;

		} else if(( p = strstr(argv[i], "--f3=")) != NULL)
		{
			p = strstr(argv[i], "=") + 1;
			sprintf(filename_3, "%s", p);
			in_fn_3 = filename_3;

		} else if(( p = strstr(argv[i], "--f4=")) != NULL)
		{
			p = strstr(argv[i], "=") + 1;
			sprintf(filename_4, "%s", p);
			in_fn_4 = filename_4;

		} else if(( p = strstr(argv[i], "--out=")) != NULL)
		{
			p = strstr(argv[i], "=") + 1;
			sprintf(output_filename, "%s", p);
			out_fn = output_filename;

		} else if(( p = strstr(argv[i], "--bg=")) != NULL)
		{
			p = strstr(argv[i], "=") + 1;
			sprintf(background_filename, "%s", p);
			bg_fn = background_filename;

		} else if(( p = strstr(argv[i], "--off=")) != NULL)
		{
			p = strstr(argv[i], "=") + 1;
			start_row = atoi(p);
			row_offset = &start_row;
		} else if(( p = strstr(argv[i], "--help")) != NULL)
		{
		//	fprintf(stderr, "usage: %s --f1=<path to file 1> --f2=<path to file 2> [OPTIONAL PARAMETERS]\n", argv[0]);
			fprintf(stderr, "usage: %s [OPTIONS]\n", argv[0]);
			return 0;
		} else if(( p = strstr(argv[i], "--default")) != NULL)
		{
			sprintf(filename_1, "%s", "nlm_output/baboon_1.tiff");
			sprintf(filename_2, "%s", "nlm_output/baboon_2.tiff");
			sprintf(filename_3, "%s", "nlm_output/baboon_0.tiff");
			sprintf(filename_4, "%s", "nlm_output/noise_baboon.tiff");
			sprintf(background_filename, "%s", "data/template.tiff");
			sprintf(output_filename, "%s", "combine_image.tiff");
			row_offset = NULL;
			in_fn_1 = filename_1;
			in_fn_2 = filename_2;
			in_fn_3 = filename_3;
			in_fn_4 = filename_4;
			bg_fn = background_filename;
			out_fn = output_filename;
		}

	}
/*
	char * filename_1 = "nlm_output/baboon_1.tiff";
	char * filename_2 = "nlm_output/baboon_2.tiff";
	char * filename_3 = "nlm_output/baboon_0.tiff";
	char * filename_4 = "nlm_output/noise_baboon.tiff";
	char * background_filename = "data/template.tiff";
	char * output_filename = "combine_image.tiff";
*/



	result = combine_images(bg_fn, out_fn, in_fn_1, in_fn_2, in_fn_3, in_fn_4, row_offset);

	return result;

}




int32_t func_otsu_threshold(uint8_t * src_data, uint32_t data_size)
{
	uint8_t image_hist[256] = { 0 };
	uint32_t image_hist_size;
	int32_t m;
	int32_t n;
	double max_sigma;
	int32_t threshold;
	int32_t alpha_1;
	int32_t beta_1;

	image_hist_size = 256;

	for(uint32_t i = 0; i < data_size; i++)
	{
		image_hist[src_data[i]]++;
	}

	m = 0;
	n = 0;

	for(uint32_t i = 0; i < image_hist_size; i++)
	{
		n += image_hist[i];
		m += i * image_hist[i];
	}

	max_sigma = -1.0f;
	threshold = 0;
	alpha_1 = 0;
	beta_1 = 0;

	for(uint32_t i = 0; i < image_hist_size; i++)
	{
		alpha_1 += i * image_hist[i];
		beta_1 += image_hist[i];

		double w_1;
		double average;
		double sigma;

		w_1 = (double)(beta_1)/(double)(n);
		average = (double)(alpha_1)/(double)(beta_1) - (double)(m - alpha_1)/(double)(n - beta_1);

		sigma = w_1 * (1.0f - w_1) * average * average;

		if(sigma > max_sigma)
		{
			max_sigma = sigma;
			threshold = i;
		}

	}

	return threshold;

}




void func_binarize_image(uint8_t * src_data, uint8_t * out_data, uint32_t data_size, int32_t threshold)
{

	for(uint32_t i = 0; i < data_size; i++)
	{
		if(src_data[i] >= threshold)
		{
			out_data[i] = 0;
		}
		else
		{
			out_data[i] = 255;
		}
	}

}

int32_t func_get_neigh(uint8_t * src_data, uint8_t * map_data, uint32_t data_size, uint32_t w, uint32_t h, uint32_t i)
{
	int32_t buffer[4] = { 0 };
	int32_t map_buffer[4] = { 0 };

	int32_t x;
	int32_t y;

	int32_t obj_label;

	x = i % w;
	y = i / w;
	obj_label = 0;


	if(x > 0)
	{
		buffer[0] = src_data[i - 1];
		map_buffer[0] = map_data[i - 1];
	}
	if(x < w - 1)
	{
		buffer[2] = src_data[i + 1];
		map_buffer[2] = map_data[i + 1];
	}
	if(y > 0)
	{
		buffer[1] = src_data[i - w];
		map_buffer[1] = map_data[i - w];
	}
	if(y < h - 1)
	{
		buffer[3] = src_data[i + w];
		map_buffer[3] = map_data[i + w];
	}

	for(uint32_t j = 0; j < 4; j++)
	{
		if(buffer[j] == 255 && map_buffer[j] > 0)
		{
			obj_label = (uint8_t)(map_buffer[j]);
			return obj_label;
		}
	}

	return obj_label;

}

uint32_t func_select_objects_4(uint8_t * src_data, uint8_t * obj_map, uint32_t data_size, uint32_t w, uint32_t h)
{

	uint32_t object_counter;
	object_counter = 0;

	for(uint32_t i = 0; i < data_size; i++)
	{
		if(src_data[i] == 0)
		{
			continue;
		}

		if(obj_map[i] > 0)
		{
			continue;
		}

		int32_t obj_label;
		obj_label = func_get_neigh(src_data, obj_map, data_size, w, h, i);

		if(obj_label == 0)
		{
			object_counter++;
			obj_map[i] = object_counter;
		}
		else
		{
			obj_map[i] = (uint8_t)(obj_label);
		}

	}

	return object_counter;

}

int32_t func_select_objects_4_other(uint8_t * src_data, uint8_t * obj_map, uint32_t data_size, uint32_t w, uint32_t h)
{

	int32_t o_counter;
	int32_t o_counter_2;

	uint32_t x_max;
	uint32_t y_max;

	int32_t B;
	int32_t A;
	int32_t C;

	x_max = w;
	y_max = h;

	o_counter = 0;
	o_counter_2 = 0;

	memcpy(obj_map, src_data, data_size);

	for(uint32_t y = 0; y < y_max; y++)
	{
		for(uint32_t x = 0; x < x_max; x++)
		{
			int32_t kn;
			int32_t km;
			kn = x - 1;
			if(kn < 0)
			{
				kn = 0;
				B = 0;
			}
			else
			{
				B = obj_map[ y * w + kn ];

			}

			km = y - 1;
			if(km < 0)
			{
				km = 0;
				C = 0;
			}
			else
			{
				C = obj_map[ km * w + x ];
			}

			A = obj_map[ y * w + x ];

			if(A == 0)
			{

			}
			else
			{
				if(B == 0 && C == 0)
				{
					o_counter += 1;
					o_counter_2++;
					obj_map[ y * w + x ] = o_counter;
				}
				else
				{
					if(B != 0 && C == 0)
					{
						obj_map[ y * w + x ] = B;
					}
					else
					{
						if(B == 0 && C != 0)
						{
							obj_map[ y * w + x ] = C;
						}
						else
						{
							if(B != 0 && C != 0)
							{
								if(B == C)
								{
									obj_map[ y * w + x ] = B;
								}
								else
								{
									obj_map[ y * w + x ] = B;
									o_counter_2--;
									for(uint32_t ii = 0; ii < data_size; ii++)
									{
										if(obj_map[ii] == C)
										{
											obj_map[ii] = B;
										}
									}
								}
							}
						}
					}
				}
			}

		}
	}


	return o_counter_2;

}


int32_t func_select_objects_4_other_other(uint8_t * src_data, int32_t * obj_map, uint32_t data_size, uint32_t w, uint32_t h)
{

	int32_t o_counter;
	int32_t o_counter_2;

	uint32_t x_max;
	uint32_t y_max;

	int32_t B;
	int32_t A;
	int32_t C;

	x_max = w;
	y_max = h;

	o_counter = 0;
	o_counter_2 = 0;


	for(uint32_t y = 0; y < y_max; y++)
	{
		for(uint32_t x = 0; x < x_max; x++)
		{
			int32_t kn;
			int32_t km;
			kn = x - 1;
			if(kn < 0)
			{
				kn = 0;
				B = 0;
			}
			else
			{
				B = obj_map[ y * w + kn ];

			}

			km = y - 1;
			if(km < 0)
			{
				km = 0;
				C = 0;
			}
			else
			{
				C = obj_map[ km * w + x ];
			}

			A = obj_map[ y * w + x ];

			if(A == 0)
			{

			}
			else
			{
				if(B == 0 && C == 0)
				{
					o_counter += 1;
					o_counter_2++;
					obj_map[ y * w + x ] = o_counter;
				}
				else
				{
					if(B != 0 && C == 0)
					{
						obj_map[ y * w + x ] = B;
					}
					else
					{
						if(B == 0 && C != 0)
						{
							obj_map[ y * w + x ] = C;
						}
						else
						{
							if(B != 0 && C != 0)
							{
								if(B == C)
								{
									obj_map[ y * w + x ] = B;
								}
								else
								{
									obj_map[ y * w + x ] = B;
									o_counter_2--;
									for(uint32_t ii = 0; ii < data_size; ii++)
									{
										if(obj_map[ii] == C)
										{
											obj_map[ii] = B;
										}
									}
								}
							}
						}
					}
				}
			}

		}
	}


	return o_counter_2;

}


