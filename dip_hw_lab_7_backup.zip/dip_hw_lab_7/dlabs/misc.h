
#ifndef H_MISC
#define H_MISC


#include "stdint.h"


#define MAX_LABELS_BUFFER_SIZE	4096


struct st_moments
{
	uint64_t m00;
	uint64_t m01;
	uint64_t m10;
	double mu20;
	double mu02;
	double mu11;

	uint64_t u20;
	uint64_t u02;
	int64_t u11;

};


int32_t func_in_buffer(int32_t value, int32_t * buffer, uint32_t buffer_size);
void func_print_moments(struct st_moments * data);
void func_calc_momemnts(uint8_t * src_data, int32_t * label_map, uint32_t w, uint32_t h, int32_t label, struct st_moments * result);
int32_t func_get_img_object_size(int32_t * label_map, uint32_t label_map_size, int32_t label);
void func_fill_object(uint8_t * new_img, int32_t * label_map, uint32_t w, uint32_t h, int32_t label);
int32_t bin_img_main(int32_t argc, char **argv);



#endif


