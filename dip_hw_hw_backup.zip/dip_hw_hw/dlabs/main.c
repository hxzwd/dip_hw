

#include "proc.h"
#include "misc.h"

#define DEBUG		1
#define DEBUG_NLM 	1
#define DEBUG_RF	1

#undef DEBUG_NLM
#undef DEBUG_RF
#undef DEBUG

#define NLM_MAIN	1
#undef NLM_MAIN


#define BIN_IMG		1
#undef BIN_IMG


#define NLM_MAIN	1
//#undef NLM_MAIN


#include "time.h"




int32_t main(int32_t argc, char **argv)
{

#ifdef BIN_IMG

	return bin_img_main(argc, argv);

#endif


#ifdef DEBUG

	return debug_main(argc, argv);

#else

#ifdef NLM_MAIN

	int32_t status;

	char input_fn[256] = { 0 };
	char output_fn[256] = { 0 };

	sprintf(input_fn, "data/noise_baboon.tiff");
	sprintf(output_fn, "nlm_output/default_output_0.tiff");

	double sigma_param;
	double h_param;
	uint32_t S;
	uint32_t K;
	uint32_t L;
	uint32_t M;

	sigma_param = 1.0f;
	h_param = 100.0f;
	S = 7;
	K = 7;
	L = 3;
	M = 3;

	char * arg_value_ptr;


	for(uint32_t i = 1 ; i < argc ; i++)
	{
		if((arg_value_ptr = strstr(argv[i], "--in=")) != NULL)
		{
			arg_value_ptr = strstr(argv[i], "=") + 1;
			sprintf(input_fn, "%s", arg_value_ptr);

		} else if((arg_value_ptr = strstr(argv[i], "--out=")) != NULL)
		{
			arg_value_ptr = strstr(argv[i], "=") + 1;
			sprintf(output_fn, "%s", arg_value_ptr);

		} else if((arg_value_ptr = strstr(argv[i], "--sigma=")) != NULL)
		{
			arg_value_ptr = strstr(argv[i], "=") + 1;
			sigma_param = strtod(arg_value_ptr, NULL);

		} else if((arg_value_ptr = strstr(argv[i], "--h=")) != NULL)
		{
			arg_value_ptr = strstr(argv[i], "=") + 1;
			h_param = strtod(arg_value_ptr, NULL);

		} else if((arg_value_ptr = strstr(argv[i], "--S=")) != NULL)
		{
			arg_value_ptr = strstr(argv[i], "=") + 1;
			S = atoi(arg_value_ptr);

		} else if((arg_value_ptr = strstr(argv[i], "--K=")) != NULL)
		{
			arg_value_ptr = strstr(argv[i], "=") + 1;
			K = atoi(arg_value_ptr);
		} else if((arg_value_ptr = strstr(argv[i], "--L=")) != NULL)
		{
			arg_value_ptr = strstr(argv[i], "=") + 1;
			L = atoi(arg_value_ptr);
		} else if((arg_value_ptr = strstr(argv[i], "--M=")) != NULL)
		{
			arg_value_ptr = strstr(argv[i], "=") + 1;
			M = atoi(arg_value_ptr);
		} else if((arg_value_ptr = strstr(argv[i], "--help")) != NULL)
		{
			fprintf(stderr, "usage: %s [OPTIONS]\n", argv[0]);
			fprintf(stderr, "OPTIONS LIST:\n");
			fprintf(stderr, "\t--in=<path to .tiff file> - input image file\n");
			fprintf(stderr, "\t--out=<path to .tiff file> - output image file\n");
			fprintf(stderr, "\t--sigma=<float> - parameter sigma of nlm-filter\n");
			fprintf(stderr, "\t--h=<float> - parameter h of nlm-filter\n");
			fprintf(stderr, "\t--S=<uint8_t> - width of filter-window\n");
			fprintf(stderr, "\t--K=<uint8_t> - height of filter-window\n");
			fprintf(stderr, "\t--L=<uint8_t> - width of compare block\n");
			fprintf(stderr, "\t--M=<uint8_t> - height of compare block\n");
			fprintf(stderr, "\t--combine - combine .tiff images\n");

			return 0;
		} else if((arg_value_ptr = strstr(argv[i], "--combine")) != NULL)
		{

			return combine_main(argc, argv);

		}


	}


	fprintf(stderr, "[main.c:main()] NLM filter of .tiff image.\n");
	fprintf(stderr, "[main.c:main()] Use %s as input image\n", input_fn);
	fprintf(stderr, "[main.c:main()] Use %s as output image\n", output_fn);
	fprintf(stderr, "[main.c:main()] Parameters of nlm-filter (sigma, h, S, K, L, M):\n");
	fprintf(stderr, "\tsigma = %f\n\th = %f\n\t", sigma_param, h_param);
	fprintf(stderr, "S = %d\n\tK = %d\n\tL = %d\n\tM = %d\n", S, K, L, M);
	fprintf(stderr, "[main.c:main()] Call nlm_main() function...\n");


	status = nlm_main(input_fn, output_fn, sigma_param, h_param, S, K, L, M);

	fprintf(stderr, "[main.c:main()] Status of nlm_main() is %d\n", status);
	fprintf(stderr, "[main.c:main()] Return status = %d\n", status);

	return status;

#else

	int32_t status;

	char filename[128] = { 0 };
	char output[128] = { 0 };
	char paramfile[128] = { 0 };

	if(argc >= 2)
	{
		strcpy(filename, argv[1]);
		if(argc >= 3)
		{
			strcpy(output, argv[2]);
			if(argc >= 4)
			{
				strcpy(paramfile, argv[3]);
			}
		}
	}
	else
	{
		fprintf(stderr, "usage: %s <input file> [<output file> [<param file>]]\n");
		return -1;
	}

	status = proc_image(filename, output, paramfile);

	if(status >= 0)
	{
		fprintf(stderr, "proc_image() status = %d\nOk!\n", status);
		return status;
	}
	else
	{
		fprintf(stderr, "proc_image() status = %d\nError!\n", status);
		return status;
	}


	return 0;

#endif
#endif

}



/*
	int8_t * noise;
	uint32_t noise_size = img.size;
	noise = (int8_t *)malloc(sizeof(int8_t) * noise_size);
	generate_normal_noise(noise, noise_size, 0.0f, 25.0f);
	for(uint32_t i = 0; i < img.size; i++)
	{
		int32_t noised = img.data[i] + noise[i];
		if(noised > 255)
			noised = 255;
		if(noised < 0)
			noised = 0;
		tmp_buf[i] = (uint8_t)(noised);
	}
	f_save_tiff_2("noised_baboon.tiff", &tiff, tmp_buf, tmp_buf_size);

	if(tmp_buf)
		free(tmp_buf);
	if(noise)
		free(noise);

	f_close_image(&img);
	f_close_tiff(&tiff);

	return 0;
*/
