#!/bin/bash


TARGET_DIR=out_imgs
TARGET_DIR=$(pwd)

if [[ $1 == "start" ]]
then
#	cd out_imgs
	./bin_server 8080 &> /dev/null &
#	cd ../
	exit
fi

if [[ $1 == "kill" ]]
then
	pkill bin_server
	exit
fi

if [[ $1 == "status" ]]
then
	STATUS=`ps -ef | grep bin_server | grep -v grep`
	if [[ $STATUS == "" ]]
	then
		echo "Not running"
	else
		echo -e "$STATUS"
	fi
	exit
fi

echo "Usage: $0 <start|kill|status>"

