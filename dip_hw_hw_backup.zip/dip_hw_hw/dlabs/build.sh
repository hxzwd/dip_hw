#!/bin/bash

gcc main.c proc.c misc.c -o bin_main -std=c99 -lm


