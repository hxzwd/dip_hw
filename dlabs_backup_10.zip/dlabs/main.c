

#include "proc.h"


#define DEBUG		1
#define DEBUG_NLM 	1
#define DEBUG_RF	1

#undef DEBUG_NLM
#undef DEBUG_RF
#undef DEBUG

#define NLM_MAIN	1
#undef NLM_MAIN


#define BIN_IMG		1
//#undef BIN_IMG


#include "time.h"




void func_binarize_image(uint8_t * src_data, uint8_t * out_data, uint32_t data_size, int32_t threshold)
{

	for(uint32_t i = 0; i < data_size; i++)
	{
		if(src_data[i] >= threshold)
		{
			out_data[i] = 0;
		}
		else
		{
			out_data[i] = 255;
		}
	}

}

int32_t func_get_neigh(uint8_t * src_data, uint8_t * map_data, uint32_t data_size, uint32_t w, uint32_t h, uint32_t i)
{
	int32_t buffer[4] = { 0 };
	int32_t map_buffer[4] = { 0 };

	int32_t x;
	int32_t y;

	int32_t obj_label;

	x = i % w;
	y = i / w;
	obj_label = 0;


	if(x > 0)
	{
		buffer[0] = src_data[i - 1];
		map_buffer[0] = map_data[i - 1];
	}
	if(x < w - 1)
	{
		buffer[2] = src_data[i + 1];
		map_buffer[2] = map_data[i + 1];
	}
	if(y > 0)
	{
		buffer[1] = src_data[i - w];
		map_buffer[1] = map_data[i - w];
	}
	if(y < h - 1)
	{
		buffer[3] = src_data[i + w];
		map_buffer[3] = map_data[i + w];
	}

	for(uint32_t j = 0; j < 4; j++)
	{
		if(buffer[j] == 255 && map_buffer[j] > 0)
		{
			obj_label = (uint8_t)(map_buffer[j]);
			return obj_label;
		}
	}

	return obj_label;

}

uint32_t func_select_objects_4(uint8_t * src_data, uint8_t * obj_map, uint32_t data_size, uint32_t w, uint32_t h)
{

	uint32_t object_counter;
	object_counter = 0;

	for(uint32_t i = 0; i < data_size; i++)
	{
		if(src_data[i] == 0)
		{
			continue;
		}

		if(obj_map[i] > 0)
		{
			continue;
		}

		int32_t obj_label;
		obj_label = func_get_neigh(src_data, obj_map, data_size, w, h, i);

		if(obj_label == 0)
		{
			object_counter++;
			obj_map[i] = object_counter;
		}
		else
		{
			obj_map[i] = (uint8_t)(obj_label);
		}

	}

	return object_counter;

}

int32_t func_select_objects_4_other(uint8_t * src_data, uint8_t * obj_map, uint32_t data_size, uint32_t w, uint32_t h)
{

	int32_t o_counter;
	int32_t o_counter_2;

	uint32_t x_max;
	uint32_t y_max;

	int32_t B;
	int32_t A;
	int32_t C;

	x_max = w;
	y_max = h;

	o_counter = 0;
	o_counter_2 = 0;

	memcpy(obj_map, src_data, data_size);

	for(uint32_t y = 0; y < y_max; y++)
	{
		for(uint32_t x = 0; x < x_max; x++)
		{
			int32_t kn;
			int32_t km;
			kn = x - 1;
			if(kn < 0)
			{
				kn = 0;
				B = 0;
			}
			else
			{
				B = obj_map[ y * w + kn ];

			}

			km = y - 1;
			if(km < 0)
			{
				km = 0;
				C = 0;
			}
			else
			{
				C = obj_map[ km * w + x ];
			}

			A = obj_map[ y * w + x ];

			if(A == 0)
			{

			}
			else
			{
				if(B == 0 && C == 0)
				{
					o_counter += 1;
					o_counter_2++;
					obj_map[ y * w + x ] = o_counter;
				}
				else
				{
					if(B != 0 && C == 0)
					{
						obj_map[ y * w + x ] = B;
					}
					else
					{
						if(B == 0 && C != 0)
						{
							obj_map[ y * w + x ] = C;
						}
						else
						{
							if(B != 0 && C != 0)
							{
								if(B == C)
								{
									obj_map[ y * w + x ] = B;
								}
								else
								{
									obj_map[ y * w + x ] = B;
									o_counter_2--;
									for(uint32_t ii = 0; ii < data_size; ii++)
									{
										if(obj_map[ii] == C)
										{
											obj_map[ii] = B;
										}
									}
								}
							}
						}
					}
				}
			}

		}
	}


	return o_counter_2;

}


int32_t func_select_objects_4_other_other(uint8_t * src_data, int32_t * obj_map, uint32_t data_size, uint32_t w, uint32_t h)
{

	int32_t o_counter;
	int32_t o_counter_2;

	uint32_t x_max;
	uint32_t y_max;

	int32_t B;
	int32_t A;
	int32_t C;

	x_max = w;
	y_max = h;

	o_counter = 0;
	o_counter_2 = 0;


	for(uint32_t y = 0; y < y_max; y++)
	{
		for(uint32_t x = 0; x < x_max; x++)
		{
			int32_t kn;
			int32_t km;
			kn = x - 1;
			if(kn < 0)
			{
				kn = 0;
				B = 0;
			}
			else
			{
				B = obj_map[ y * w + kn ];

			}

			km = y - 1;
			if(km < 0)
			{
				km = 0;
				C = 0;
			}
			else
			{
				C = obj_map[ km * w + x ];
			}

			A = obj_map[ y * w + x ];

			if(A == 0)
			{

			}
			else
			{
				if(B == 0 && C == 0)
				{
					o_counter += 1;
					o_counter_2++;
					obj_map[ y * w + x ] = o_counter;
				}
				else
				{
					if(B != 0 && C == 0)
					{
						obj_map[ y * w + x ] = B;
					}
					else
					{
						if(B == 0 && C != 0)
						{
							obj_map[ y * w + x ] = C;
						}
						else
						{
							if(B != 0 && C != 0)
							{
								if(B == C)
								{
									obj_map[ y * w + x ] = B;
								}
								else
								{
									obj_map[ y * w + x ] = B;
									o_counter_2--;
									for(uint32_t ii = 0; ii < data_size; ii++)
									{
										if(obj_map[ii] == C)
										{
											obj_map[ii] = B;
										}
									}
								}
							}
						}
					}
				}
			}

		}
	}


	return o_counter_2;

}

int32_t func_in_buffer(int32_t value, int32_t * buffer, uint32_t buffer_size)
{
	if(value == 0)
	{
		return 0;
	}
	for(uint32_t i = 0; i < buffer_size; i++)
	{
		if(buffer[i] == 0)
		{
			break;
		}
		if(buffer[i] == value)
		{
			return 1;
		}
	}
	return 0;
}

struct st_moments
{
	uint64_t m00;
	uint64_t m01;
	uint64_t m10;
	double mu20;
	double mu02;
	double mu11;

	uint64_t u20;
	uint64_t u02;
	int64_t u11;

};

void func_print_moments(struct st_moments * data)
{
	fprintf(stderr, "----------------------------------------------\n");
	fprintf(stderr, "m00 = %u\n", data->m00);
	fprintf(stderr, "m01 = %u\n", data->m01);
	fprintf(stderr, "m10 = %u\n", data->m10);
	fprintf(stderr, "mu20 = %f\n", data->mu20);
	fprintf(stderr, "mu02 = %f\n", data->mu02);
	fprintf(stderr, "mu11 = %f\n", data->mu11);
	fprintf(stderr, "u20 = %u\n", data->u20);
	fprintf(stderr, "u02 = %u\n", data->u02);
	fprintf(stderr, "u11 = %u\n", data->u11);
	fprintf(stderr, "----------------------------------------------\n");
}

void func_calc_momemnts(uint8_t * src_data, int32_t * label_map, uint32_t w, uint32_t h, int32_t label, struct st_moments * result)
{
	uint64_t m00;
	uint64_t m01;
	uint64_t m10;

	double mu20;
	double mu02;
	double mu11;

	m00 = 0;
	m01 = 0;
	m10 = 0;

	mu20 = 0.0f;
	mu02 = 0.0f;
	mu11 = 0.0f;

	for(uint32_t y = 0; y < h; y++)
	{
		for(uint32_t x = 0; x < w; x++)
		{
			if(label_map[ y * w + x ] == label)
			{
				m00 += src_data[ y * w + x];
				m10 += (x + 1) * src_data[ y * w + x ];
				m01 += (y + 1) * src_data[ y * w + x ];
			}
		}
	}

	result->m00 = m00;
	result->m01 = m01;
	result->m10 = m10;

	double xc;
	double yc;

	uint64_t xci;
	uint64_t yci;
	uint64_t u02;
	uint64_t u20;
	int64_t u11;

	xc = (double)(m10)/(double)(m00);
	yc = (double)(m01)/(double)(m00);

	xci = (uint64_t)(xc);
	yci = (uint64_t)(yc);

	u02 = 0;
	u20 = 0;
	u11 = 0;
	fprintf(stderr, "xc = %f\tyc = %f\n", xc, yc);
	fprintf(stderr, "xci = %d\tyci = %d\n", xci, yci);

	for(uint32_t y = 0; y < h; y++)
	{
		for(uint32_t x = 0; x < w; x++)
		{
			if(label_map[ y * w + x ] == label)
			{
				mu20 += (double)(((x + 1) - xc) * ((x + 1) - xc) * (double)(src_data[ y * w + x ]));
				mu02 += (double)(((y + 1) - yc) * ((y + 1) - yc) * (double)(src_data[ y * w + x ]));
				mu11 += (double)(((x + 1) - xc) * ((y + 1) - yc) * (double)(src_data[ y * w + x ]));
				u20 += ((x + 1) - xci) * ((x + 1) - xci) * src_data[ y * w + x ];
				u02 += ((y + 1) - yci) * ((y + 1) - yci) * src_data[ y * w + x ];
				u11 += ((x + 1) - xci) * ((y + 1) - yci) * src_data[ y * w + x ];
			}
		}
	}

	result->mu20 = mu20;
	result->mu02 = mu02;
	result->mu11 = mu11;

	result->u20 = u20;
	result->u02 = u02;
	result->u11 = u11;

	return;

}

int32_t func_get_img_object_size(int32_t * label_map, uint32_t label_map_size, int32_t label)
{
	int32_t object_size;

	object_size = 0;

	for(uint32_t i = 0; i < label_map_size; i++)
	{
		if(label_map[i] == label)
		{
			object_size++;
		}
	}

	return object_size;

}

void func_fill_object(uint8_t * new_img, int32_t * label_map, uint32_t w, uint32_t h, int32_t label)
{

	for(uint32_t y = 0; y < h; y++)
	{
		for(uint32_t x = 0; x < w; x++)
		{
			if(label_map[ y * w + x ] == label)
			{
				new_img[ y * w + x ] = 255;
			}
			else
			{
				new_img[ y * w + x ] = 0;
			}
		}
	}

	return;

} 

int32_t bin_img_main(int32_t argc, char **argv)
{
	fprintf(stderr, "[bin_img_main()] Lab 7 task!\nOk!...\n");


//	char *filename = "data/noise_baboon.tiff";
	char * filename = "data/bagira.tiff";
	struct st_image img;
	struct st_tiff_file tiff;

	f_open_tiff(filename, &img, &tiff);

	fprintf(stderr, "Image size: %d\n", img.size);
	fprintf(stderr, "Image data addr: 0x%08X\n", img.data);


	if(tiff.tiff_data)
	{
		fprintf(stderr, "Tiff file name: %s\n", tiff.filename);
		fprintf(stderr, "Read status: Ok! [tiff data poiner = 0x%08X]\n", tiff.tiff_data);
	}

	if(!img.data || !tiff.tiff_data)
	{

		f_close_image(&img);
		f_close_tiff(&tiff);

		return -1;
	}



	uint8_t * tmp_buf;
	uint32_t tmp_buf_size;
	tmp_buf = (uint8_t *)malloc(sizeof(uint8_t)*img.size);
	if(!tmp_buf)
	{
		fprintf(stderr, "Error malloc for tmp_buf [size: %d bytes]\n", sizeof(uint8_t)*img.size);
		f_close_image(&img);
		f_close_tiff(&tiff);

		return -1;
	}
	tmp_buf_size = img.size;

	memcpy(tmp_buf, img.data, tmp_buf_size);

	int32_t threshold;

	threshold = func_otsu_threshold(tmp_buf, tmp_buf_size);

	threshold = 60;

	func_binarize_image(img.data, tmp_buf, tmp_buf_size, threshold);

	uint8_t * tmp_buf_2 = (uint8_t *)(malloc(sizeof(uint8_t) * img.size));
	memset(tmp_buf_2, 0, img.size);

	int32_t * tmp_buf_3 = (int32_t *)(malloc(sizeof(int32_t) * img.size));

	for(uint32_t i = 0; i < img.size; i++)
	{
		tmp_buf_3[i] = (int32_t)(tmp_buf[i]);
	}

//	uint32_t obj_num = func_select_objects_4(tmp_buf, tmp_buf_2, img.size, img.w, img.h);
//	fprintf(stderr, "OBJ_NUM = %d\n", obj_num);

	int32_t obj_num_other = func_select_objects_4_other(tmp_buf, tmp_buf_2, img.size, img.w, img.h);
	fprintf(stderr, "OBJ_NUM_OTHER = %d\n", obj_num_other);

	int32_t obj_num_other_other = func_select_objects_4_other_other(tmp_buf, tmp_buf_3, img.size, img.w, img.h);
	fprintf(stderr, "OBJ_NUM_OTHER_OTHER = %d\n", obj_num_other_other);

	int32_t labels_buffer[4096] = { 0 };
	uint32_t labels_counter;
	uint32_t labels_buffer_size;
	labels_counter = 0;
	labels_buffer_size = 4096;

	for(uint32_t i = 0; i < img.size; i++)
	{
		if(tmp_buf_3[i] == 0)
		{
			continue;
		}
		if(!func_in_buffer(tmp_buf_3[i], labels_buffer, labels_buffer_size))
		{
			labels_buffer[labels_counter++] = tmp_buf_3[i];
		}
		else
		{
			continue;
		}
	}

	fprintf(stderr, "labels_counter = %d\n", labels_counter);
	for(uint32_t i = 0; i < labels_counter; i++)
	{
		if(i % 2 == 0 && i != 0)
		{
			fprintf(stderr, "\n");
		}
		int32_t object_size;
		object_size = func_get_img_object_size(tmp_buf_3, img.size, labels_buffer[i]);
		fprintf(stderr, "labels_buffer[%04d] = %04d (size: %05d)\t", i, labels_buffer[i], object_size);

	}
	fprintf(stderr, "\n");

	for(uint32_t i = 0; i < 3; i++)
	{
		struct st_moments data;
		fprintf(stderr, "Calc moments for label = %d\n", labels_buffer[i]);
		func_calc_momemnts(img.data, tmp_buf_3, img.w, img.h, labels_buffer[i], &data);
		func_print_moments(&data);
	}

	uint8_t * tmp_buf_4 = (uint8_t *)(malloc(sizeof(uint8_t) * img.size));

	func_fill_object(tmp_buf_4, tmp_buf_3, img.w, img.h, labels_buffer[2]);
	f_save_tiff_2("img_objects/bagira_label_2.tiff", &tiff, tmp_buf_4, img.size);
	
	func_fill_object(tmp_buf_4, tmp_buf_3, img.w, img.h, labels_buffer[187]);
	f_save_tiff_2("img_objects/bagira_label_187.tiff", &tiff, tmp_buf_4, img.size);

	if(tmp_buf_4)
	{
		// f_save_tiff_2("img_objects/bagira_label_2.tiff", &tiff, tmp_buf_4, img.size);
		free(tmp_buf_4);
	}


	if(tmp_buf_3)
	{
		free(tmp_buf_3);
	}


	if(tmp_buf)
	{
//		f_save_tiff_2("binarized_noise_baboon.tiff", &tiff, tmp_buf, tmp_buf_size);
		f_save_tiff_2("binarized_bagira.tiff", &tiff, tmp_buf, tmp_buf_size);
	}

	if(tmp_buf_2)
	{
//		f_save_tiff_2("binarized_noise_baboon_map.tiff", &tiff, tmp_buf_2, tmp_buf_size);
		f_save_tiff_2("binarized_bagira_map.tiff", &tiff, tmp_buf_2, tmp_buf_size);
		free(tmp_buf_2);
	}

	if(tmp_buf)
	{
		free(tmp_buf);
	}

	f_close_image(&img);
	f_close_tiff(&tiff);

	return 0;



	uint8_t * src_data;
	uint8_t * res_data;
	uint32_t w, h, S, K, L, M;
	double sigma_param, h_param;
	src_data = img.data;
	res_data = tmp_buf;
	w = img.w;
	h = img.h;
	S = 7; K = 7;
	L = 3; M = 3;
	sigma_param = 1.0f; h_param = 1.0f;

	debug_print(&img, 25, 10);


	nlm_filter(src_data, res_data, w, h, S, K, L, M, sigma_param, h_param);
	if(tmp_buf)
		f_save_tiff_2("nlm_filter_noise_baboon.tiff", &tiff, tmp_buf, tmp_buf_size);

	debug_print(&img, 25, 10);


	if(tmp_buf)
		free(tmp_buf);

	f_close_image(&img);
	f_close_tiff(&tiff);

	return 0;


	return 0;

}

int32_t main(int32_t argc, char **argv)
{

#ifdef BIN_IMG

	return bin_img_main(argc, argv);

#endif


#ifdef DEBUG

	return debug_main(argc, argv);

#else

#ifdef NLM_MAIN

	int32_t status;

	char input_fn[256] = { 0 };
	char output_fn[256] = { 0 };

	sprintf(input_fn, "data/noise_baboon.tiff");
	sprintf(output_fn, "nlm_output/default_output_0.tiff");

	double sigma_param;
	double h_param;
	uint32_t S;
	uint32_t K;
	uint32_t L;
	uint32_t M;

	sigma_param = 1.0f;
	h_param = 100.0f;
	S = 7;
	K = 7;
	L = 3;
	M = 3;

	char * arg_value_ptr;


	for(uint32_t i = 1 ; i < argc ; i++)
	{
		if((arg_value_ptr = strstr(argv[i], "--in=")) != NULL)
		{
			arg_value_ptr = strstr(argv[i], "=") + 1;
			sprintf(input_fn, "%s", arg_value_ptr);

		} else if((arg_value_ptr = strstr(argv[i], "--out=")) != NULL)
		{
			arg_value_ptr = strstr(argv[i], "=") + 1;
			sprintf(output_fn, "%s", arg_value_ptr);

		} else if((arg_value_ptr = strstr(argv[i], "--sigma=")) != NULL)
		{
			arg_value_ptr = strstr(argv[i], "=") + 1;
			sigma_param = strtod(arg_value_ptr, NULL);

		} else if((arg_value_ptr = strstr(argv[i], "--h=")) != NULL)
		{
			arg_value_ptr = strstr(argv[i], "=") + 1;
			h_param = strtod(arg_value_ptr, NULL);

		} else if((arg_value_ptr = strstr(argv[i], "--S=")) != NULL)
		{
			arg_value_ptr = strstr(argv[i], "=") + 1;
			S = atoi(arg_value_ptr);

		} else if((arg_value_ptr = strstr(argv[i], "--K=")) != NULL)
		{
			arg_value_ptr = strstr(argv[i], "=") + 1;
			K = atoi(arg_value_ptr);
		} else if((arg_value_ptr = strstr(argv[i], "--L=")) != NULL)
		{
			arg_value_ptr = strstr(argv[i], "=") + 1;
			L = atoi(arg_value_ptr);
		} else if((arg_value_ptr = strstr(argv[i], "--M=")) != NULL)
		{
			arg_value_ptr = strstr(argv[i], "=") + 1;
			M = atoi(arg_value_ptr);
		} else if((arg_value_ptr = strstr(argv[i], "--help")) != NULL)
		{
			fprintf(stderr, "usage: %s [OPTIONS]\n", argv[0]);
			fprintf(stderr, "OPTIONS LIST:\n");
			fprintf(stderr, "\t--in=<path to .tiff file> - input image file\n");
			fprintf(stderr, "\t--out=<path to .tiff file> - output image file\n");
			fprintf(stderr, "\t--sigma=<float> - parameter sigma of nlm-filter\n");
			fprintf(stderr, "\t--h=<float> - parameter h of nlm-filter\n");
			fprintf(stderr, "\t--S=<uint8_t> - width of filter-window\n");
			fprintf(stderr, "\t--K=<uint8_t> - height of filter-window\n");
			fprintf(stderr, "\t--L=<uint8_t> - width of compare block\n");
			fprintf(stderr, "\t--M=<uint8_t> - height of compare block\n");
			fprintf(stderr, "\t--combine - combine .tiff images\n");

			return 0;
		} else if((arg_value_ptr = strstr(argv[i], "--combine")) != NULL)
		{

			return combine_main(argc, argv);

		}


	}


	fprintf(stderr, "[main.c:main()] NLM filter of .tiff image.\n");
	fprintf(stderr, "[main.c:main()] Use %s as input image\n", input_fn);
	fprintf(stderr, "[main.c:main()] Use %s as output image\n", output_fn);
	fprintf(stderr, "[main.c:main()] Parameters of nlm-filter (sigma, h, S, K, L, M):\n");
	fprintf(stderr, "\tsigma = %f\n\th = %f\n\t", sigma_param, h_param);
	fprintf(stderr, "S = %d\n\tK = %d\n\tL = %d\n\tM = %d\n", S, K, L, M);
	fprintf(stderr, "[main.c:main()] Call nlm_main() function...\n");


	status = nlm_main(input_fn, output_fn, sigma_param, h_param, S, K, L, M);

	fprintf(stderr, "[main.c:main()] Status of nlm_main() is %d\n", status);
	fprintf(stderr, "[main.c:main()] Return status = %d\n", status);

	return status;

#else

	int32_t status;

	char filename[128] = { 0 };
	char output[128] = { 0 };
	char paramfile[128] = { 0 };

	if(argc >= 2)
	{
		strcpy(filename, argv[1]);
		if(argc >= 3)
		{
			strcpy(output, argv[2]);
			if(argc >= 4)
			{
				strcpy(paramfile, argv[3]);
			}
		}
	}
	else
	{
		fprintf(stderr, "usage: %s <input file> [<output file> [<param file>]]\n");
		return -1;
	}

	status = proc_image(filename, output, paramfile);

	if(status >= 0)
	{
		fprintf(stderr, "proc_image() status = %d\nOk!\n", status);
		return status;
	}
	else
	{
		fprintf(stderr, "proc_image() status = %d\nError!\n", status);
		return status;
	}


	return 0;

#endif
#endif

}



/*
	int8_t * noise;
	uint32_t noise_size = img.size;
	noise = (int8_t *)malloc(sizeof(int8_t) * noise_size);
	generate_normal_noise(noise, noise_size, 0.0f, 25.0f);
	for(uint32_t i = 0; i < img.size; i++)
	{
		int32_t noised = img.data[i] + noise[i];
		if(noised > 255)
			noised = 255;
		if(noised < 0)
			noised = 0;
		tmp_buf[i] = (uint8_t)(noised);
	}
	f_save_tiff_2("noised_baboon.tiff", &tiff, tmp_buf, tmp_buf_size);

	if(tmp_buf)
		free(tmp_buf);
	if(noise)
		free(noise);

	f_close_image(&img);
	f_close_tiff(&tiff);

	return 0;
*/
