

#include "proc.h"


#define DEBUG		1
#define DEBUG_NLM 	1
#undef DEBUG_NLM
#undef DEBUG

#include "time.h"

void generate_normal_noise(int8_t * noise, uint32_t buffer_size, double mean, double std)
{
	srand(time(NULL));

	double epsilon = 0.000000000f;
	double x, y;
	double z, z0, z1;
	double s;

	for(uint32_t i = 0; i < buffer_size; i++)
	{
		x = (double)(rand() / RAND_MAX) * 2.0 - 1.0;
		y = (double)(rand() / RAND_MAX) * 2.0 - 1.0;
		s = x * x  + y * y;
		if(abs(s - 0.0 - epsilon) > 0.0 && abs(s - 1.0) <= epsilon)
		{
			z0 = x * sqrt(-2.0f * log(s) / s);
			z1 = y * sqrt(-2.0f * log(s) / s);
			z = mean + z0 * std;
			noise[i] = (int8_t)(z);
		}
		else
		{
			i--;
			continue;
		}
	}

}


void debug_print(struct st_image * img, uint32_t row_len, uint32_t columns_num)
{

	for(uint32_t j = 0; j < columns_num; j++)
	{
		for(uint32_t i = 0; i < row_len; i++)
		{
			fprintf(stderr, "%03d ", img->data[j * img->w + i]);
		}
	fprintf(stderr, "\n");
	}

}


double block_affinity_func(uint8_t * src_data, uint32_t w, uint32_t h, uint32_t M, uint32_t L, double sigma_param, double h_param, uint32_t r, uint32_t c, uint32_t i, uint32_t j)
{

	uint32_t half_size_x = M/2;
	uint32_t half_size_y = L/2;

	double res;

	res = 0.0f;

	for(uint32_t y = 0; y < L; ++y)
	{
		for(uint32_t x = 0; x < M; ++x)
		{
			uint8_t * p_block_1 = (uint8_t *)(&(src_data[(r - half_size_y + y)*w + c - half_size_x + x]));
			uint8_t * p_block_2 = (uint8_t *)(&(src_data[(r + i - half_size_y + y)*w + c + j - half_size_x + x]));
			int32_t I1 = (int32_t)(*p_block_1);
			int32_t I2 = (int32_t)(*p_block_2);
		#ifdef DEBUG_NLM
			fprintf(stderr, "I1 = %d; I2 = %d\n", I1, I2);
		#endif

			int32_t k = (int32_t)(y) - (int32_t)(half_size_y);
			int32_t n = (int32_t)(x) - (int32_t)(half_size_x);
			res += (I1 - I2)*(I1 - I2)*exp(-(k * k + n * n)/(2.0 * sigma_param * sigma_param));
		}
	}

#ifdef DEBUG_NLM
	fprintf(stderr, "block_affinity_func(): s = %.2f; h = %.2f:\n", sigma_param, h_param);
	fprintf(stderr, "res = %f\n", res);

	res = exp(-res/(h_param * h_param));

	fprintf(stderr, "res = %f\n", res);
#else
	res = exp(-res/(h_param * h_param));
#endif

	return res;

}

void nlm_filter(uint8_t * src_data, uint8_t * res_data, uint32_t w, uint32_t h, uint32_t S, uint32_t K, uint32_t L, uint32_t M, double sigma_param, double h_param)
{

	uint32_t half_size_x = S / 2;
	uint32_t half_size_y = K / 2;
	uint32_t half_size_bx = L / 2;
	uint32_t half_size_by = M / 2;
	memcpy(res_data, src_data, sizeof(uint8_t) * w *  h);

	for(uint32_t y = half_size_y + half_size_by; y < h - half_size_y - half_size_by; ++y)
	{

		for(uint32_t x = half_size_x + half_size_bx; x < w - half_size_x - half_size_bx; ++x)
		{

		#ifdef DEBUG_NLM
			fprintf(stderr, "x = %d; y = %d [data: %d]\n", x, y, src_data[y * w + x]);
		#endif
			double d11 = 0.0;
			double d00 = 0.0;
			int32_t rs;

			for(uint32_t v = y - half_size_y; v < y + half_size_y; ++v)
			{
				for(uint32_t u = x - half_size_x; u < x + half_size_x; ++u)
				{


					double d0;
					double d1;
					d0 = block_affinity_func(src_data, w, h, M, L, sigma_param, h_param, y, x, v - y, u - x);
					d1 = (double)(src_data[v * w + u])*d0;
					d00 += d0;
					d11 += d1;
				#ifdef DEBUG_NLM
					fprintf(stderr, "u = %d; v = %d [data: %d] [d0: %f] [d1: %f]\n", u, v, src_data[v * w + u], d0, d1);
				#endif

				}
			}

			rs = (int32_t)(d11 / d00);
		#ifdef DEBUG_NLM
			fprintf(stderr, "rs = %d; d11 = %f; d00 = %f\n", rs, d11, d00);
		#endif
			if(rs > 255)
			{
				rs = 255;
			} else if(rs < 0)
			{
				rs = 0;
			}

			res_data[y * w + x] = (uint8_t)(rs);
		#ifdef DEBUG_NLM
			break;
		#endif
		}
	#ifdef DEBUG_NLM
		break;
	#endif
	}

}



int32_t debug_main(int32_t argc, char **argv)
{

	char *filename = "data/noise_baboon.tiff";
	struct st_image img;
	struct st_tiff_file tiff;

	f_open_tiff(filename, &img, &tiff);

	fprintf(stderr, "Image size: %d\n", img.size);
	fprintf(stderr, "Image data addr: 0x%08X\n", img.data);


	if(tiff.tiff_data)
	{
		fprintf(stderr, "Tiff file name: %s\n", tiff.filename);
		fprintf(stderr, "Read status: Ok! [tiff data poiner = 0x%08X]\n", tiff.tiff_data);
	}

	if(!img.data || !tiff.tiff_data)
	{

		f_close_image(&img);
		f_close_tiff(&tiff);

		return -1;
	}



	uint8_t * tmp_buf;
	uint32_t tmp_buf_size;
	tmp_buf = (uint8_t *)malloc(sizeof(uint8_t)*img.size);
	if(!tmp_buf)
	{
		fprintf(stderr, "Error malloc for tmp_buf [size: %d bytes]\n", sizeof(uint8_t)*img.size);
		f_close_image(&img);
		f_close_tiff(&tiff);

		return -1;
	}
	tmp_buf_size = img.size;

	uint8_t * src_data;
	uint8_t * res_data;
	uint32_t w, h, S, K, L, M;
	double sigma_param, h_param;
	src_data = img.data;
	res_data = tmp_buf;
	w = img.w;
	h = img.h;
	S = 7; K = 7;
	L = 3; M = 3;
	sigma_param = 1.0f; h_param = 1.0f;

	debug_print(&img, 25, 10);


	nlm_filter(src_data, res_data, w, h, S, K, L, M, sigma_param, h_param);
	if(tmp_buf)
		f_save_tiff_2("nlm_filter_noise_baboon.tiff", &tiff, tmp_buf, tmp_buf_size);

	debug_print(&img, 25, 10);


	if(tmp_buf)
		free(tmp_buf);

	f_close_image(&img);
	f_close_tiff(&tiff);

	return 0;

}



int32_t main(int32_t argc, char **argv)
{

#ifdef DEBUG

	return debug_main(argc, argv);

#else

	int32_t status;

	char filename[128] = { 0 };
	char output[128] = { 0 };
	char paramfile[128] = { 0 };

	if(argc >= 2)
	{
		strcpy(filename, argv[1]);
		if(argc >= 3)
		{
			strcpy(output, argv[2]);
			if(argc >= 4)
			{
				strcpy(paramfile, argv[3]);
			}
		}
	}
	else
	{
		fprintf(stderr, "usage: %s <input file> [<output file> [<param file>]]\n");
		return -1;
	}

	status = proc_image(filename, output, paramfile);

	if(status >= 0)
	{
		fprintf(stderr, "proc_image() status = %d\nOk!\n", status);
		return status;
	}
	else
	{
		fprintf(stderr, "proc_image() status = %d\nError!\n", status);
		return status;
	}


	return 0;

#endif

}



/*
	int8_t * noise;
	uint32_t noise_size = img.size;
	noise = (int8_t *)malloc(sizeof(int8_t) * noise_size);
	generate_normal_noise(noise, noise_size, 0.0f, 25.0f);
	for(uint32_t i = 0; i < img.size; i++)
	{
		int32_t noised = img.data[i] + noise[i];
		if(noised > 255)
			noised = 255;
		if(noised < 0)
			noised = 0;
		tmp_buf[i] = (uint8_t)(noised);
	}
	f_save_tiff_2("noised_baboon.tiff", &tiff, tmp_buf, tmp_buf_size);

	if(tmp_buf)
		free(tmp_buf);
	if(noise)
		free(noise);

	f_close_image(&img);
	f_close_tiff(&tiff);

	return 0;
*/
