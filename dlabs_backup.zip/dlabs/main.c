
#include "stdio.h"
#include "stdlib.h"
#include "stdint.h"
#include "string.h"
#include "math.h"

#define TAG_WIDTH		0x100	//image width
#define TAG_LENGTH		0x101	//image length
#define TAG_BPS			0x102	//bits per sample
#define	TAG_COMPRESSION		0x103	//using type of compression
#define TAG_PH_INTERP		0x106	//using color model
#define TAG_FILL_ORDER		0x10A	//logical order of bits in bytes
#define TAG_STRIP_OFF		0x111	//offset for rows in bytes
#define TAG_ORIENTATION		0x112	//image orientation
#define TAG_SPP			0x115	//samples per pixel
#define TAG_RPS			0x116	//rows per strip
#define TAG_SBC			0x117	//bytes per rows
#define TAG_X_RES		0x11A	//number of pixels in rows in resolution units
#define TAG_Y_RES		0x11B	//number of pixels in columns in resolution units
#define TAG_PL_CONF		0x11C	//planar configuration
#define TAG_RES			0x128	//resolution of data
#define TAG_UNKNOWN_0		0x129	//
#define TAG_UNKNOWN_1		0x13D	//
#define TAG_UNKNOWN_2		0x13E	//
#define TAG_UNKNOWN_3		0x13F	//
#define TAG_EX_SAMPLES		0x152	//extra samples

#define NUM_OF_TAGS		20

struct st_tag_names
{
	uint16_t tag;
	char * name;
	char * description;
};

struct st_tag_names tag_names_list[] = {
	{ TAG_WIDTH, "WIDTH", "image width" },
	{ TAG_LENGTH, "LENGTH", "image length" },
	{ TAG_BPS, "BPS", "bits per sample" },
	{ TAG_COMPRESSION, "TAG_COMPRESSION", "using type of compression" },
	{ TAG_PH_INTERP, "TAG_PH_INTERP", "using color model" },
	{ TAG_FILL_ORDER, "TAG_FILL_ORDER", "logical order of bits in bytes" },
	{ TAG_STRIP_OFF, "TAG_STRIP_OFF", "offset for rows in bytes" },
	{ TAG_ORIENTATION, "TAG_ORIENTATION", "image orientation" },
	{ TAG_SPP, "TAG_SPP", "samples per pixel" },
	{ TAG_RPS, "TAG_RPS", "rows per strip" },
	{ TAG_SBC, "TAG_SBC", "bytes per rows" },
	{ TAG_X_RES, "TAG_X_RES", "number of pixels in rows in resolution units" },
	{ TAG_Y_RES, "TAG_Y_RES", "number of pixels in columns in resolution units" },
	{ TAG_PL_CONF, "TAG_PL_CONF", "planar configuration" },
	{ TAG_RES, "TAG_RES", "resolution of data" },
	{ TAG_UNKNOWN_0, "TAG_UNKNOWN_0", "" },
	{ TAG_UNKNOWN_1, "TAG_UNKNOWN_1", "" },
	{ TAG_UNKNOWN_2, "TAG_UNKNOWN_2", "" },
	{ TAG_UNKNOWN_3,  "TAG_UNKNOWN_3", "" },
	{ TAG_EX_SAMPLES, "TAG_EX_SAMPLES", "extra samples" }
};


char * field_types_names[] = {
	NULL,
	"byte",
	"ascii",
	"short",
	"long",
	"rational",
	NULL
};

enum enum_field_types
{
	TYPE_BYTE = 1,
	TYPE_ASCII,
	TYPE_SHORT,		//16-bit (2 bytes)
	TYPE_LONG,		//32-bit (4 bytes)
	TYPE_RATIONAL  		//two longs (numerator and denominator)
};

struct st_ifd_entry
{
	uint16_t tag;
	uint16_t field_type;
	uint32_t num_of_values;
	uint32_t offset;
};


void dprint(uint16_t value)
{
	fprintf(stderr, "%d [0x%04X]", value, value);
}


void dprint16(uint16_t value)
{
	fprintf(stderr, "%d [0x%04X]", value, value);
}


void dprint8(uint8_t value)
{
	fprintf(stderr, "%d [0x%02X]", value, value);
}


void dprint32(uint32_t value)
{
	fprintf(stderr, "%d [0x%08X]", value, value);
}

void dnl(void)
{
	fprintf(stderr, "\n");
}


void dprint_ifd(struct st_ifd_entry * ifd_entry)
{
	fprintf(stderr, "tag:          \t\t"); dprint(ifd_entry->tag); dnl();
	fprintf(stderr, "field type:   \t\t");
	dprint(ifd_entry->field_type); fprintf(stderr, " (%s)\n", field_types_names[ifd_entry->field_type]);
	fprintf(stderr, "num of values:\t\t"); dprint32(ifd_entry->num_of_values); dnl();
	fprintf(stderr, "values offset:\t\t"); dprint32(ifd_entry->offset); dnl();
}

int32_t f_read_ifd(struct st_ifd_entry * ifd_entry, FILE *fd)
{
	uint16_t tmp;
	uint32_t value;
	int32_t result = 0;
	result += fread(&tmp, sizeof(uint16_t), 1, fd);
	ifd_entry->tag = tmp;
	result += fread(&tmp, sizeof(uint16_t), 1, fd);
	ifd_entry->field_type = tmp;
	result += fread(&value, sizeof(uint32_t), 1, fd);
	ifd_entry->num_of_values = value;
	result += fread(&value, sizeof(uint32_t), 1, fd);
	ifd_entry->offset = value;
	return result;
}

uint32_t f_from_offset32(FILE *fd, uint32_t offset)
{
	fpos_t old_pos;
	uint32_t value;

	fgetpos(fd, &old_pos);
	fseek(fd, offset, SEEK_SET);
	fread(&value, sizeof(uint32_t), 1, fd);
	fsetpos(fd, &old_pos);
	return value;
}

uint16_t f_from_offset16(FILE *fd, uint32_t offset)
{
	fpos_t old_pos;
	uint16_t value;

	fgetpos(fd, &old_pos);
	fseek(fd, offset, SEEK_SET);
	fread(&value, sizeof(uint16_t), 1, fd);
	fsetpos(fd, &old_pos);
	return value;
}

uint8_t f_from_offset8(FILE *fd, uint32_t offset)
{
	fpos_t old_pos;
	uint32_t value;

	fgetpos(fd, &old_pos);
	fseek(fd, offset, SEEK_SET);
	fread(&value, sizeof(uint8_t), 1, fd);
	fsetpos(fd, &old_pos);
	return value;
}


struct st_image
{
	uint32_t w;
	uint32_t h;
	uint8_t * data;
	uint32_t size;
};

struct st_tiff_file
{
	char filename[128];
	uint32_t file_size;
	uint8_t * tiff_data;
	uint32_t data_offset;
	uint32_t data_size;
};

int32_t f_open_tiff(char *filename, struct st_image * image, struct st_tiff_file * tiff)
{

	FILE * fd;
	uint32_t buffer[512];
	uint32_t value;
	uint16_t tmp;
	struct st_ifd_entry ifd_entry;

	uint32_t data_offset;
	uint32_t data_size;

	uint32_t bytes_readed;

	if((fd = fopen(filename, "rb")) == NULL)
	{
		fprintf(stderr, "Error open image file: %s for read\n", filename);
		return -1;
	}


	fread(&tmp, sizeof(uint16_t), 1, fd);
	dprint(tmp); dnl();
	fread(&tmp, sizeof(uint16_t), 1, fd);
	dprint(tmp); dnl();
	fread(&value, sizeof(uint32_t), 1, fd);
	dprint32(value), dnl();

	fseek(fd, value, SEEK_SET);

	fread(&tmp, sizeof(uint16_t), 1, fd);
	fprintf(stderr, "Num of directory entries: \n");
	dprint(tmp); dnl();


	for(uint32_t i = 0; i < tmp; i++)
	{
		fprintf(stderr, "IFD NUM: %d\n", i);
//		f_read_ifd(&ifd_entry, fd);
		fread(&ifd_entry, sizeof(struct st_ifd_entry), 1, fd);
		dprint_ifd(&ifd_entry);

		for(uint32_t j = 0; j < NUM_OF_TAGS; j++)
		{
			if(tag_names_list[j].tag == ifd_entry.tag)
			{
				fprintf(stderr, "Tag name: %s\n", tag_names_list[j].name);
				fprintf(stderr, "Tag description: %s\n", tag_names_list[j].description);
			}
		}

		if(ifd_entry.tag == TAG_WIDTH)
		{
			image->w = ifd_entry.offset;
		} else if(ifd_entry.tag == TAG_LENGTH)
		{
			image->h = ifd_entry.offset;
		} else if(ifd_entry.tag == TAG_STRIP_OFF)
		{
			data_offset = ifd_entry.offset;
		} else if(ifd_entry.tag == TAG_SBC)
		{
			data_size = ifd_entry.offset;
		}

/*
		if(ifd_entry.tag == TAG_WIDTH || ifd_entry.tag == TAG_LENGTH)
		{
			uint32_t tmp0;
			tmp0 = f_from_offset32(fd, ifd_entry.offset);
			dprint32(tmp0); dnl();
		} else if(ifd_entry.tag == TAG_BPS || ifd_entry.tag == TAG_STRIP_OFF)
		{
			uint32_t tmp0 = f_from_offset32(fd, ifd_entry.offset);
			dprint32(tmp0); dnl();
		} else if(ifd_entry.tag == TAG_SBC)
		{
			uint32_t tmp0 = f_from_offset32(fd, ifd_entry.offset);
			dprint32(tmp0); dnl();
		}
*/
	}

	fread(&value, sizeof(uint32_t),1, fd);
	fprintf(stderr, "OFFSET OF NEXT IFD: "); dprint32(value); dnl();

	image->data = (uint8_t *)malloc(sizeof(uint8_t)*data_size);
	if(!image->data)
	{
		fprintf(stderr, "Memory allocation error (for image data) bytes required: %d\n", sizeof(uint8_t) * data_size);
		fclose(fd);
		image->size = 0;
		return -1;
	}

	fseek(fd, data_offset, SEEK_SET);

	bytes_readed = fread(image->data, sizeof(uint8_t), data_size, fd);
	image->size = data_size;

	if(data_size != bytes_readed)
	{
		fprintf(stderr, "Read file errors [bytes_readed != data_size] %d != %d\n", bytes_readed, data_size);
		fclose(fd);
		if(!image->data)
			free(image->data);
		image->size = 0;
		return -1;
	}
	else
	{
		fprintf(stderr, "Ok!... bytes_readed = %d = data_size = %d\n", bytes_readed, data_size);
	}

	if(tiff)
	{
		rewind(fd);
		fseek(fd, 0, SEEK_END);
		uint32_t file_size = ftell(fd);
		rewind(fd);
		tiff->file_size = file_size;
		strcpy(tiff->filename, filename);
		tiff->data_offset = data_offset;
		tiff->data_size = data_size;
		tiff->tiff_data = (uint8_t *)malloc(sizeof(uint8_t)*file_size);
		if(!tiff->tiff_data)
		{
			fprintf(stderr, "Memory allocation error (for tiff data) bytes required: %d\n", sizeof(uint8_t) * file_size);
			fclose(fd);
			tiff->data_offset = 0;
			tiff->tiff_data = 0;
			return -1;
		}
		if(tiff->tiff_data)
			fread(tiff->tiff_data, sizeof(uint8_t), file_size, fd);

	}


	fclose(fd);

	return 0;

}

int32_t f_save_tiff(char *filename, struct st_tiff_file * tiff, struct st_image * img)
{
	if(img != NULL)
	{
		if(img->data != NULL && tiff->tiff_data != NULL)
		{
			memcpy((void *)(&((tiff->tiff_data)[tiff->data_offset])), (void *)(img->data), tiff->data_size);
		}
	}

	FILE * fd;
	int32_t status;
	uint32_t bytes_writed;

	if((fd = fopen(filename, "wb")) == NULL)
	{
		fprintf(stderr, "Error open image file : %s for saving\n", filename);
		return -1;
	}


//	fd = fopen(filename, "wb");

	bytes_writed = fwrite(tiff->tiff_data, sizeof(uint8_t), tiff->file_size, fd);

	if(bytes_writed != tiff->file_size)
	{
		fprintf(stderr, "Save tiff errors [bytes_writed != file_size : %d != %d]\n", bytes_writed, tiff->file_size);
		status = -1;
	}
	else
	{
		fprintf(stderr, "Save tiff status:\nOk!... [bytes_writed = %d = file_size]\n", bytes_writed, tiff->file_size);
		status = 0;
	}
	fclose(fd);

	return status;

}


int32_t f_save_tiff_2(char *filename, struct st_tiff_file * tiff, uint8_t * data_buffer, uint32_t data_buffer_size)
{

	if(!data_buffer_size)
		data_buffer_size = tiff->data_size;


	struct st_image tmp_img;
	int32_t status;

	tmp_img.size = data_buffer_size;
	tmp_img.data = data_buffer;

	status =  f_save_tiff(filename, tiff, &tmp_img);

	return status;
}


void f_convolution_2(uint8_t * src_data, uint8_t * res_data, uint32_t w, uint32_t h, int32_t * kernel_data, uint32_t kernel_size, int32_t kernel_coeff)
{

	if(!kernel_coeff)
		kernel_coeff = 1;

	uint32_t half_size = kernel_size / 2;
	memcpy(res_data, src_data, sizeof(uint8_t) * w *  h);

	for(uint32_t y = half_size; y < h - half_size; ++y)
	{
		for(uint32_t x = half_size; x < w - half_size; ++x)
		{
			uint32_t * pk = kernel_data;
			uint8_t * ps = &(src_data[(y - half_size) * w + x - half_size]);
			int32_t conv_sum = 0;
			for(uint32_t v = 0; v < kernel_size; ++v)
			{
				for(uint32_t u = 0; u < kernel_size; u++)
				{
					conv_sum += ps[u] * pk[u];
				}
				pk += kernel_size;
				ps += w;
			}
			conv_sum = conv_sum / kernel_coeff;
			if(conv_sum > 255)
			{
				conv_sum = 255;
			} else if(conv_sum < 0)
			{
				conv_sum = 0;
			}
			res_data[y*w + x] = (uint8_t)(conv_sum);
		}
	}

}


double block_affinity_func(uint8_t * src_data, uint32_t w, uint32_t h, uint32_t M, uint32_t L, double sigma_param, double h_param, uint32_t r, uint32_t c, uint32_t i, uint32_t j)
{

	uint32_t half_size_x = M/2;
	uint32_t half_size_y = L/2;

	double func_res;

	func_res = 0.0f;

	for(uint32_t y = 0; y < L; ++y)
	{
		for(uint32_t x = 0; x < M; ++x)
		{
			uint8_t * p_block_1 = (uint8_t *)(&(src_data[(r - half_size_y + y)*w + c - half_size_x + x]));
			uint8_t * p_block_2 = (uint8_t *)(&(src_data[(r + i - half_size_y + y)*w + c + j - half_size_x + x]));
			int32_t I1 = (int32_t)(*p_block_1);
			int32_t I2 = (int32_t)(*p_block_2);
			int32_t k = (int32_t)(y) - (int32_t)(half_size_y);
			int32_t n = (int32_t)(x) - (int32_t)(half_size_x);
			func_res += (I1 - I2)*(I1 - I2)*exp(-(k*k + n*n)/(2.0*sigma_param*sigma_param));
		}
	}

	func_res = exp(-func_res/(h_param*h_param));
	return func_res;

}

void nlm_filter(uint8_t * src_data, uint8_t * res_data, uint32_t w, uint32_t h, uint32_t S, uint32_t K, uint32_t L, uint32_t M, double sigma_param, double h_param)
{

	uint32_t half_size_x = S / 2;
	uint32_t half_size_y = K / 2;
	uint32_t half_size_bx = L / 2;
	uint32_t half_size_by = M / 2;
	memcpy(res_data, src_data, sizeof(uint8_t) * w *  h);

	for(uint32_t y = half_size_y + half_size_by; y < h - half_size_y - half_size_by; ++y)
	{

		for(uint32_t x = half_size_x + half_size_bx; x < w - half_size_x - half_size_bx; ++x)
		{

			double res_num = 0.0;
			double res_denom = 0.0;
			int32_t res_int;

			for(uint32_t v = y - half_size_y; v < y + half_size_y; ++v)
			{
				for(uint32_t u = x - half_size_x; u < x + half_size_x; ++u)
				{
					double tmp_value;
					tmp_value = block_affinity_func(src_data, w, h, M, L, sigma_param, h_param, y, x, v, u);
					res_denom += tmp_value;
					res_num += (double)(src_data[v*w + u])*tmp_value;
				}
			}

			res_int = (int32_t)(res_num/res_denom);

			if(res_int > 255)
			{
				res_int = 255;
			} else if(res_int < 0)
			{
				res_int = 0;
			}

			res_data[y*w + x] = (uint8_t)(res_int);

		}

	}

}


void f_close_tiff(struct st_tiff_file * tiff)
{
	if(tiff->tiff_data)
		free(tiff->tiff_data);
	strcpy(tiff->filename, "");
	tiff->data_offset = 0;
	tiff->data_size = 0;
	tiff->file_size = 0;
}

void f_close_image(struct st_image * img)
{
	if(img->data)
		free(img->data);
	img->w = 0;
	img->h = 0;
	img->size = 0;
	img->data = NULL;
}

struct st_kernel
{
	uint32_t size;
	int32_t coeff;
	int32_t * data;
};

void f_close_kernel(struct st_kernel * kernel)
{
	if(kernel->data)
		free(kernel->data);
	kernel->size = 0;
	kernel->coeff = 0;
}

int32_t str_to_array(char * str, int32_t * array, uint32_t num_count, uint32_t array_size)
{
	char * p;
	uint32_t counter = 0;


	p = strtok(str, " ,\n");
	array[counter] = (int32_t)(atoi(p));
	counter++;

	do
	{
		if(p && counter < array_size)
		{
			array[counter] = (int32_t)(atoi(p));
			counter++;
		}
		if(counter >= num_count)
			break;

	}
	while(p);

	return counter;

}

int32_t get_kernel_param(char * paramfile, struct st_kernel * kernel)
{
	FILE * fd;
	char tmp_buf[8192];
	uint32_t file_size;
	uint32_t bytes_readed;
	char * line;

	uint32_t kernel_size = 0;
	int32_t kernel_coeff = 1;

//	fd = fopen(paramfile, "rb");
	if((fd = fopen(paramfile, "rb")) == NULL)
	{
		fprintf(stderr, "Error open parameters file: %s\n", paramfile);
		return -1;
	}



	fseek(fd, 0, SEEK_END);
	file_size = ftell(fd);
	rewind(fd);

	bytes_readed = fread(tmp_buf, sizeof(char), file_size, fd);
	if(bytes_readed != file_size)
	{
		fclose(fd);
		fprintf(stderr, "Error reading params file: %s [bytes_readed != file_size ; %d != %d]\n", paramfile, bytes_readed, file_size);
		return -1;
	}
	else
	{
		fprintf(stderr, "Reading params file: %s status is\nOk!... [bytes_readed = %d = file_size = %d]\n", paramfile, bytes_readed, file_size);
	}

	line = strtok(tmp_buf, "\n");
	uint32_t str_counter = 0;
	uint32_t flag_kernel_data = 0;
	if(!strcmp("[kernel]", line))
	{
		do
		{
			line = strtok(NULL, "\n");
			if(strstr(line, "size"))
			{
				char * tmp_str;
				tmp_str = strstr(line, "=") + 1;
				kernel_size = (uint32_t)(atoi(tmp_str));
				kernel->data = (int32_t *)malloc(sizeof(int32_t) * kernel_size * kernel_size);
				if(!kernel->data)
				{
					fprintf(stderr, "Memory allocation error (for kernel data) bytes required: %d\n", sizeof(int32_t) * kernel_size * kernel_size);
					kernel->size = 0;
					kernel->coeff = 0;
					return -1;
				}
				kernel->size = kernel_size;
			} else if(strstr(line, "coeff"))
			{
				char * tmp_str;
				tmp_str = strstr(line, "=") + 1;
				kernel_coeff = (uint32_t)(atoi(tmp_str));
				kernel->coeff = kernel_coeff;
			} else if(strstr(line, "data:") || flag_kernel_data)
			{
				if(!flag_kernel_data)
				{
					flag_kernel_data = 1;
					continue;
				}
				int32_t tmp_array[512];
				uint32_t tmp_array_size = 512;
				int32_t num_in_str;
				num_in_str = str_to_array(line, tmp_array, kernel_size, tmp_array_size);
				if(num_in_str != kernel_size)
				{
					fprintf(stderr, "Error read kernel data from param file: %s\n", paramfile);
					fprintf(stderr, "Count of numbers in string is %d ( should be %d ) [ string counter: %d]\n", num_in_str, kernel_size, str_counter);
					if(kernel->data)
						free(kernel->data);
					kernel->data = NULL;
					kernel->size = 0;
					kernel->coeff = 0;
					return -1;
				}
				for(uint32_t i = 0; i < kernel_size; i++)
				{
					kernel->data[i + kernel_size * str_counter] = tmp_array[i];
				}
				str_counter++;
				if(str_counter >= kernel_size)
				{
					flag_kernel_data = 0;
					break;
				}
			} else
			{
				if(flag_kernel_data)
				{
					fprintf(stderr, "Error read kernel data from param file: %s\n", paramfile);
					fprintf(stderr, "Count of rows of kernel matrix is %d ( should be %d )\n", str_counter, kernel_size);
					if(kernel->data)
						free(kernel->data);
					kernel->data = NULL;
					kernel->size = 0;
					kernel->coeff = 0;
					return -1;
				}
			}
		}
		while(line);
	}

	return 0;

}

void f_show_kernel(struct st_kernel * kernel)
{
	fprintf(stderr, "Convolution kernel info:\n");
	fprintf(stderr, "\tsize = %d x %d\n", kernel->size, kernel->size);
	fprintf(stderr, "\tcoeff = %d\n", kernel->coeff);
	if(kernel->data)
	{
		fprintf(stderr, "data = \n");
		for(uint32_t i = 0; i < kernel->size * kernel->size; i++)
		{
			if(i % kernel->size == 0 && i != 0)
				fprintf(stderr, "\n");
			fprintf(stderr, "%d\t", kernel->data[i]);
		}
	}
	fprintf(stderr, "\n");

}

int32_t proc_image(char * filename, char * output, char * paramfile)
{

	uint8_t * tmp_buf;
	uint32_t tmp_buf_size;

	int32_t * kernel_data;
	uint32_t kernel_size;
	int32_t kernel_coeff;

	struct st_image img;
	struct st_tiff_file tiff;
	struct st_kernel kernel;

	img.data = NULL;
	tiff.tiff_data = NULL;
	kernel.data = NULL;
	tmp_buf = NULL;
	kernel_data = NULL;
	tmp_buf_size = 0;
	kernel_size = 0;
	kernel_coeff = 0;

	int32_t status;

	char * default_filename = "data/baboon.tiff";
	char * default_output = "output.tiff";
	char * default_paramfile = "param.txt";

	if(!filename || !strcmp(filename, ""))
		filename = default_filename;
	if(!output || !strcmp(output, ""))
		output = default_output;
	if(!paramfile || !strcmp(paramfile, ""))
		paramfile = default_paramfile;

	fprintf(stderr, "Input image file: %s\n", filename);
	fprintf(stderr, "Output image file: %s\n", output);
	fprintf(stderr, "Config file: %s\n", paramfile);

	status = f_open_tiff(filename, &img, &tiff);
	if(status < 0)
	{
		fprintf(stderr, "In proccess image error: f_open_tiff() status = %d\n", status);
		f_close_image(&img);
		f_close_tiff(&tiff);
		return status;
	}

	status = get_kernel_param(paramfile, &kernel);
	if(status < 0)
	{
		fprintf(stderr, "In proccess image error: get_kernel_param() status = %d\n", status);
		f_close_image(&img);
		f_close_tiff(&tiff);
		f_close_kernel(&kernel);
		return status;
	}

	f_show_kernel(&kernel);

	tmp_buf = (uint8_t *)malloc(sizeof(uint8_t) * img.size);
	if(!tmp_buf)
	{
		fprintf(stderr, "In proccess image error: allocation memory error for tmp_buf [size: %d bytes]\n", sizeof(uint8_t) * img.size);
		f_close_image(&img);
		f_close_tiff(&tiff);
		f_close_kernel(&kernel);
		return -1;
	}
	tmp_buf_size = img.size;

	kernel_data = kernel.data;
	kernel_size = kernel.size;
	kernel_coeff = kernel.coeff;

	fprintf(stderr, "Convolution image with kernel...\n");

	f_convolution_2(img.data, tmp_buf, img.w, img.h, kernel_data, kernel_size, kernel_coeff);


	if(tmp_buf)
	{
		fprintf(stderr, "Save result in output file...\n");
		status = f_save_tiff_2(output, &tiff, tmp_buf, tmp_buf_size);
		if(status < 0)
		{
			fprintf(stderr, "In proccess image error: f_save_tiff_2() status = %d\n", status);
			f_close_image(&img);
			f_close_tiff(&tiff);
			f_close_kernel(&kernel);
			if(tmp_buf)
				free(tmp_buf);
			return -1;
		}
	}

	f_close_image(&img);
	f_close_tiff(&tiff);
	f_close_kernel(&kernel);

	if(tmp_buf)
		free(tmp_buf);

	return 0;
}



int32_t main_old(void)
{

	char *filename = "data/baboon.tiff";
	struct st_image img;
	struct st_tiff_file tiff;

	f_open_tiff(filename, &img, &tiff);

	fprintf(stderr, "Image size: %d\n", img.size);
	fprintf(stderr, "Image data addr: 0x%08X\n", img.data);

	if(img.data)
		for(uint32_t i = 0; i < 16; i++)
			fprintf(stderr, "\timg.data[%d] = %d\n", i, img.data[i]);

	if(tiff.tiff_data)
	{
		fprintf(stderr, "Tiff file name: %s\n", tiff.filename);
		fprintf(stderr, "Read status: Ok! [tiff data poiner = 0x%08X]\n", tiff.tiff_data);
	}
/*
	if(img.data && tiff.tiff_data)
	{

		for(uint32_t i = 0; i < img.size; i++)
		{
			img.data[i] = 255 - img.data[i];
		}
		f_save_tiff("invert_baboon.tiff", &tiff, &img);
	}
*/
	if(!img.data || !tiff.tiff_data)
	{

		f_close_image(&img);
		f_close_tiff(&tiff);

		return -1;
	}

	uint8_t * tmp_buf;
	uint32_t tmp_buf_size;
	tmp_buf = (uint8_t *)malloc(sizeof(uint8_t)*img.size);
	if(!tmp_buf)
	{
		fprintf(stderr, "Error malloc for tmp_buf [size: %d bytes]\n", sizeof(uint8_t)*img.size);
		f_close_image(&img);
		f_close_tiff(&tiff);

		return -1;
	}
	tmp_buf_size = img.size;

	struct st_kernel kernel;
	kernel.data = NULL;

	get_kernel_param("param.txt", &kernel);
	fprintf(stderr, "kernel.size = %d\n", kernel.size);
	fprintf(stderr, "kernel.coeff = %d\n", kernel.coeff);
	if(kernel.data)
	{
		fprintf(stderr, "kernel.data = \n");
		for(uint32_t i = 0; i < kernel.size * kernel.size; i++)
		{
			if(i % kernel.size == 0 && i != 0)
				fprintf(stderr, "\n");
			fprintf(stderr, "%d ", kernel.data[i]);
		}
	}
	fprintf(stderr, "\n");

	f_close_kernel(&kernel);

	uint8_t * src_data;
	uint8_t * res_data;
	uint32_t w, h, S, K, L, M;
	double sigma_param, h_param;
	src_data = img.data;
	res_data = tmp_buf;
	w = img.w;
	h = img.h;
	S = 7; K = 7;
	L = 3; M = 3;
	sigma_param = 0.25; h_param = 0.5;

/*
	nlm_filter(src_data, res_data, w, h, S, K, L, M, sigma_param, h_param);
	if(tmp_buf)
		f_save_tiff_2("nlm_filter_baboon.tiff", &tiff, tmp_buf, tmp_buf_size);
*/

/*
	uint32_t kernel_size = 3;
	int32_t kernel_coeff = 9;
	int32_t kernel_data[ 3 * 3 ] = {
		1, 1, 1,
		1, 1, 1,
		1, 1, 1
	};

	f_convolution_2(img.data, tmp_buf, img.w, img.h, kernel_data, kernel_size, kernel_coeff);

	if(tmp_buf)
		f_save_tiff_2("convolution_baboon.tiff", &tiff, tmp_buf, tmp_buf_size);
*/


/*	if(tmp_buf)
	{
		memcpy((void *)(img.data), (void *)(tmp_buf), tmp_buf_size);
		free(tmp_buf);
	}

	f_save_tiff("convolution_baboon.tiff", &tiff, &img);
*/

	if(tmp_buf)
		free(tmp_buf);

	f_close_image(&img);
	f_close_tiff(&tiff);

	return 0;

}



int32_t main(int32_t argc, char **argv)
{
	int32_t status;

	char filename[128] = { 0 };
	char output[128] = { 0 };
	char paramfile[128] = { 0 };

	if(argc >= 2)
	{
		strcpy(filename, argv[1]);
		if(argc >= 3)
		{
			strcpy(output, argv[2]);
			if(argc >= 4)
			{
				strcpy(paramfile, argv[3]);
			}
		}
	}
	else
	{
		fprintf(stderr, "usage: %s <input file> [<output file> [<param file>]]\n");
		return -1;
	}

	status = proc_image(filename, output, paramfile);

	if(status >= 0)
	{
		fprintf(stderr, "proc_image() status = %d\nOk!\n", status);
		return status;
	}
	else
	{
		fprintf(stderr, "proc_image() status = %d\nError!\n", status);
		return status;
	}


	return 0;
}
