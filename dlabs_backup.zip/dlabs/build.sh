#!/bin/bash

gcc main.c -o bin_main -std=c99 -lm


