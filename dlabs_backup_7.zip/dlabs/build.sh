#!/bin/bash

gcc main.c proc.c -o bin_main -std=c99 -lm


