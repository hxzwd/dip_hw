
#include "stdio.h"
#include "stdlib.h"
#include "stdint.h"
#include "string.h"
#include "math.h"

#define TAG_WIDTH		0x100	//image width
#define TAG_LENGTH		0x101	//image length
#define TAG_BPS			0x102	//bits per sample
#define	TAG_COMPRESSION		0x103	//using type of compression
#define TAG_PH_INTERP		0x106	//using color model
#define TAG_FILL_ORDER		0x10A	//logical order of bits in bytes
#define TAG_STRIP_OFF		0x111	//offset for rows in bytes
#define TAG_ORIENTATION		0x112	//image orientation
#define TAG_SPP			0x115	//samples per pixel
#define TAG_RPS			0x116	//rows per strip
#define TAG_SBC			0x117	//bytes per rows
#define TAG_X_RES		0x11A	//number of pixels in rows in resolution units
#define TAG_Y_RES		0x11B	//number of pixels in columns in resolution units
#define TAG_PL_CONF		0x11C	//planar configuration
#define TAG_RES			0x128	//resolution of data
#define TAG_UNKNOWN_0		0x129	//
#define TAG_UNKNOWN_1		0x13D	//
#define TAG_UNKNOWN_2		0x13E	//
#define TAG_UNKNOWN_3		0x13F	//
#define TAG_EX_SAMPLES		0x152	//extra samples

#define NUM_OF_TAGS		20

struct st_tag_names
{
	uint16_t tag;
	char * name;
	char * description;
};

struct st_tag_names tag_names_list[] = {
	{ TAG_WIDTH, "WIDTH", "image width" },
	{ TAG_LENGTH, "LENGTH", "image length" },
	{ TAG_BPS, "BPS", "bits per sample" },
	{ TAG_COMPRESSION, "TAG_COMPRESSION", "using type of compression" },
	{ TAG_PH_INTERP, "TAG_PH_INTERP", "using color model" },
	{ TAG_FILL_ORDER, "TAG_FILL_ORDER", "logical order of bits in bytes" },
	{ TAG_STRIP_OFF, "TAG_STRIP_OFF", "offset for rows in bytes" },
	{ TAG_ORIENTATION, "TAG_ORIENTATION", "image orientation" },
	{ TAG_SPP, "TAG_SPP", "samples per pixel" },
	{ TAG_RPS, "TAG_RPS", "rows per strip" },
	{ TAG_SBC, "TAG_SBC", "bytes per rows" },
	{ TAG_X_RES, "TAG_X_RES", "number of pixels in rows in resolution units" },
	{ TAG_Y_RES, "TAG_Y_RES", "number of pixels in columns in resolution units" },
	{ TAG_PL_CONF, "TAG_PL_CONF", "planar configuration" },
	{ TAG_RES, "TAG_RES", "resolution of data" },
	{ TAG_UNKNOWN_0, "TAG_UNKNOWN_0", "" },
	{ TAG_UNKNOWN_1, "TAG_UNKNOWN_1", "" },
	{ TAG_UNKNOWN_2, "TAG_UNKNOWN_2", "" },
	{ TAG_UNKNOWN_3,  "TAG_UNKNOWN_3", "" },
	{ TAG_EX_SAMPLES, "TAG_EX_SAMPLES", "extra samples" }
};


char * field_types_names[] = {
	NULL,
	"byte",
	"ascii",
	"short",
	"long",
	"rational",
	NULL
};

enum enum_field_types
{
	TYPE_BYTE = 1,
	TYPE_ASCII,
	TYPE_SHORT,		//16-bit (2 bytes)
	TYPE_LONG,		//32-bit (4 bytes)
	TYPE_RATIONAL  		//two longs (numerator and denominator)
};

struct st_ifd_entry
{
	uint16_t tag;
	uint16_t field_type;
	uint32_t num_of_values;
	uint32_t offset;
};


void dprint(uint16_t value)
{
	fprintf(stderr, "%d [0x%04X]", value, value);
}


void dprint16(uint16_t value)
{
	fprintf(stderr, "%d [0x%04X]", value, value);
}


void dprint8(uint8_t value)
{
	fprintf(stderr, "%d [0x%02X]", value, value);
}


void dprint32(uint32_t value)
{
	fprintf(stderr, "%d [0x%08X]", value, value);
}

void dnl(void)
{
	fprintf(stderr, "\n");
}


void dprint_ifd(struct st_ifd_entry * ifd_entry)
{
	fprintf(stderr, "tag:          \t\t"); dprint(ifd_entry->tag); dnl();
	fprintf(stderr, "field type:   \t\t");
	dprint(ifd_entry->field_type); fprintf(stderr, " (%s)\n", field_types_names[ifd_entry->field_type]);
	fprintf(stderr, "num of values:\t\t"); dprint32(ifd_entry->num_of_values); dnl();
	fprintf(stderr, "values offset:\t\t"); dprint32(ifd_entry->offset); dnl();
}

int32_t f_read_ifd(struct st_ifd_entry * ifd_entry, FILE *fd)
{
	uint16_t tmp;
	uint32_t value;
	int32_t result = 0;
	result += fread(&tmp, sizeof(uint16_t), 1, fd);
	ifd_entry->tag = tmp;
	result += fread(&tmp, sizeof(uint16_t), 1, fd);
	ifd_entry->field_type = tmp;
	result += fread(&value, sizeof(uint32_t), 1, fd);
	ifd_entry->num_of_values = value;
	result += fread(&value, sizeof(uint32_t), 1, fd);
	ifd_entry->offset = value;
	return result;
}

uint32_t f_from_offset32(FILE *fd, uint32_t offset)
{
	fpos_t old_pos;
	uint32_t value;

	fgetpos(fd, &old_pos);
	fseek(fd, offset, SEEK_SET);
	fread(&value, sizeof(uint32_t), 1, fd);
	fsetpos(fd, &old_pos);
	return value;
}

uint16_t f_from_offset16(FILE *fd, uint32_t offset)
{
	fpos_t old_pos;
	uint16_t value;

	fgetpos(fd, &old_pos);
	fseek(fd, offset, SEEK_SET);
	fread(&value, sizeof(uint16_t), 1, fd);
	fsetpos(fd, &old_pos);
	return value;
}

uint8_t f_from_offset8(FILE *fd, uint32_t offset)
{
	fpos_t old_pos;
	uint32_t value;

	fgetpos(fd, &old_pos);
	fseek(fd, offset, SEEK_SET);
	fread(&value, sizeof(uint8_t), 1, fd);
	fsetpos(fd, &old_pos);
	return value;
}


struct st_image
{
	uint32_t w;
	uint32_t h;
	uint8_t * data;
	uint32_t size;
};

struct st_tiff_file
{
	char filename[128];
	uint32_t file_size;
	uint8_t * tiff_data;
	uint32_t data_offset;
	uint32_t data_size;
};

int32_t f_open_tiff(char *filename, struct st_image * image, struct st_tiff_file * tiff)
{

	FILE *fd;
	uint32_t buffer[512];
	uint32_t value;
	uint16_t tmp;
	struct st_ifd_entry ifd_entry;

	uint32_t data_offset;
	uint32_t data_size;

	uint32_t bytes_readed;

	fd = fopen(filename, "rb");


	fread(&tmp, sizeof(uint16_t), 1, fd);
	dprint(tmp); dnl();
	fread(&tmp, sizeof(uint16_t), 1, fd);
	dprint(tmp); dnl();
	fread(&value, sizeof(uint32_t), 1, fd);
	dprint32(value), dnl();

	fseek(fd, value, SEEK_SET);

	fread(&tmp, sizeof(uint16_t), 1, fd);
	fprintf(stderr, "Num of directory entries: \n");
	dprint(tmp); dnl();


	for(uint32_t i = 0; i < tmp; i++)
	{
		fprintf(stderr, "IFD NUM: %d\n", i);
//		f_read_ifd(&ifd_entry, fd);
		fread(&ifd_entry, sizeof(struct st_ifd_entry), 1, fd);
		dprint_ifd(&ifd_entry);

		for(uint32_t j = 0; j < NUM_OF_TAGS; j++)
		{
			if(tag_names_list[j].tag == ifd_entry.tag)
			{
				fprintf(stderr, "Tag name: %s\n", tag_names_list[j].name);
				fprintf(stderr, "Tag description: %s\n", tag_names_list[j].description);
			}
		}

		if(ifd_entry.tag == TAG_WIDTH)
		{
			image->w = ifd_entry.offset;
		} else if(ifd_entry.tag == TAG_LENGTH)
		{
			image->h = ifd_entry.offset;
		} else if(ifd_entry.tag == TAG_STRIP_OFF)
		{
			data_offset = ifd_entry.offset;
		} else if(ifd_entry.tag == TAG_SBC)
		{
			data_size = ifd_entry.offset;
		}

/*
		if(ifd_entry.tag == TAG_WIDTH || ifd_entry.tag == TAG_LENGTH)
		{
			uint32_t tmp0;
			tmp0 = f_from_offset32(fd, ifd_entry.offset);
			dprint32(tmp0); dnl();
		} else if(ifd_entry.tag == TAG_BPS || ifd_entry.tag == TAG_STRIP_OFF)
		{
			uint32_t tmp0 = f_from_offset32(fd, ifd_entry.offset);
			dprint32(tmp0); dnl();
		} else if(ifd_entry.tag == TAG_SBC)
		{
			uint32_t tmp0 = f_from_offset32(fd, ifd_entry.offset);
			dprint32(tmp0); dnl();
		}
*/
	}

	fread(&value, sizeof(uint32_t),1, fd);
	fprintf(stderr, "OFFSET OF NEXT IFD: "); dprint32(value); dnl();

	image->data = (uint8_t *)malloc(sizeof(uint8_t)*data_size);
	if(!image->data)
	{
		fclose(fd);
		image->size = 0;
		return -1;
	}

	fseek(fd, data_offset, SEEK_SET);

	bytes_readed = fread(image->data, sizeof(uint8_t), data_size, fd);
	image->size = data_size;

	if(data_size != bytes_readed)
	{
		fprintf(stderr, "Read file errors [bytes_readed != data_size] %d != %d\n", bytes_readed, data_size);
	}
	else
	{
		fprintf(stderr, "Ok!... bytes_readed = %d = data_size = %d\n", bytes_readed, data_size);
	}

	if(tiff)
	{
		rewind(fd);
		fseek(fd, 0, SEEK_END);
		uint32_t file_size = ftell(fd);
		rewind(fd);
		tiff->file_size = file_size;
		strcpy(tiff->filename, filename);
		tiff->data_offset = data_offset;
		tiff->data_size = data_size;
		tiff->tiff_data = (uint8_t *)malloc(sizeof(uint8_t)*file_size);
		if(tiff->tiff_data)
			fread(tiff->tiff_data, sizeof(uint8_t), file_size, fd);

	}


	fclose(fd);

	return 0;

}

int32_t f_save_tiff(char *filename, struct st_tiff_file * tiff, struct st_image * img)
{
	if(img != NULL)
	{
		if(img->data != NULL && tiff->tiff_data != NULL)
		{
			memcpy((void *)(&((tiff->tiff_data)[tiff->data_offset])), (void *)(img->data), tiff->data_size);
		}
	}

	FILE * fd;
	int32_t status;
	uint32_t bytes_writed;

	fd = fopen(filename, "wb");

	bytes_writed = fwrite(tiff->tiff_data, sizeof(uint8_t), tiff->file_size, fd);

	if(bytes_writed != tiff->file_size)
	{
		fprintf(stderr, "Save tiff errors [bytes_writed != file_size : %d != %d]\n", bytes_writed, tiff->file_size);
		status = -1;
	}
	else
	{
		fprintf(stderr, "Save tiff status:\nOk!... [bytes_writed = %d = file_size]\n", bytes_writed, tiff->file_size);
		status = 0;
	}
	fclose(fd);

	return status;

}


int32_t f_save_tiff_2(char *filename, struct st_tiff_file * tiff, uint8_t * data_buffer, uint32_t data_buffer_size)
{

	if(!data_buffer_size)
		data_buffer_size = tiff->data_size;


	struct st_image tmp_img;
	int32_t status;

	tmp_img.size = data_buffer_size;
	tmp_img.data = data_buffer;

	status =  f_save_tiff(filename, tiff, &tmp_img);

	return status;
}


void f_convolution_2(uint8_t * src_data, uint8_t * res_data, uint32_t w, uint32_t h, int32_t * kernel_data, uint32_t kernel_size, int32_t kernel_coeff)
{

	if(!kernel_coeff)
		kernel_coeff = 1;

	uint32_t half_size = kernel_size / 2;
	memcpy(res_data, src_data, sizeof(uint8_t) * w *  h);

	for(uint32_t y = half_size; y < h - half_size; ++y)
	{
		for(uint32_t x = half_size; x < w - half_size; ++x)
		{
			uint32_t * pk = kernel_data;
			uint8_t * ps = &(src_data[(y - half_size) * w + x - half_size]);
			int32_t conv_sum = 0;
			for(uint32_t v = 0; v < kernel_size; ++v)
			{
				for(uint32_t u = 0; u < kernel_size; u++)
				{
					conv_sum += ps[u] * pk[u];
				}
				pk += kernel_size;
				ps += w;
			}
			conv_sum = conv_sum / kernel_coeff;
			if(conv_sum > 255)
			{
				conv_sum = 255;
			} else if(conv_sum < 0)
			{
				conv_sum = 0;
			}
			res_data[y*w + x] = (uint8_t)(conv_sum);
		}
	}

}


double block_affinity_func(uint8_t * src_data, uint32_t w, uint32_t h, uint32_t M, uint32_t L, double sigma, double h, uint32_t r, uint32_t c, uint32_t i, uint32_t j)
{

	uint32_t half_size_x = M/2;
	uint32_t half_size_y = L/2;

	double func_res;

	func_res = 0.0f;

	for(uint32_t y = 0; y < L; ++y)
	{
		for(uint32_t x = 0; x < M; ++x)
		{
			uint8_t * p_block_1 = (uint8_t *)(&(src_data[(r - half_size_y + y)*w + c - half_size_x + x]));
			uint8_t * p_block_2 = (uint8_t *)(&(src_data[(r + i - half_size_y + y)*w + c + j - half_size_x + x]));
			int32_t I1 = (int32_t)(*p_block_1);
			int32_t I2 = (int32_t)(*p_block_2);
			int32_t k = (int32_t)(y) - (int32_t)(half_size_y);
			int32_t n = (int32_t)(x) - (int32_t)(half_size_x);
			func_res += (I1 - I2)*(I1 - I2)*exp(-(k*k + n*n)/(2.0*sigma*sigma));
		}
	}

	func_res = exp(-func_res/(h*h));
	return func_res;

}

void nlm_filter(uint8_t * src_data, uint8_t * res_data, uint32_t w, uint32_t h, uint32_t S, uint32_t K, uint32_t L, uint32_t M, double sigma, double h)
{

	uint32_t half_size_x = S / 2;
	uint32_t half_size_y = K / 2;
	memcpy(res_data, src_data, sizeof(uint8_t) * w *  h);

	for(uint32_t y = half_size_y; y < h - half_size_y; ++y)
	{

		for(uint32_t x = half_size_x; x < w - half_size_x; ++x)
		{
			uint32_t * pk = kernel_data;
//TODO
			uint8_t * ps = &(src_data[(y - half_size_y) * w + x - half_size]);
			int32_t conv_sum = 0;
			for(uint32_t v = 0; v < kernel_size; ++v)
			{
				for(uint32_t u = 0; u < kernel_size; u++)
				{
					conv_sum += ps[u] * pk[u];
				}
				pk += kernel_size;
				ps += w;
			}
			conv_sum = conv_sum / kernel_coeff;
			if(conv_sum > 255)
			{
				conv_sum = 255;
			} else if(conv_sum < 0)
			{
				conv_sum = 0;
			}
			res_data[y*w + x] = (uint8_t)(conv_sum);

		}

	}

}


void f_close_tiff(struct st_tiff_file * tiff)
{
	if(tiff->tiff_data)
		free(tiff->tiff_data);
	strcpy(tiff->filename, "");
	tiff->data_offset = 0;
	tiff->data_size = 0;
	tiff->file_size = 0;
}

void f_close_image(struct st_image * img)
{
	if(img->data)
		free(img->data);
	img->w = 0;
	img->h = 0;
	img->size = 0;
	img->data = NULL;
}

int32_t main(void)
{

	char *filename = "data/baboon.tiff";
	struct st_image img;
	struct st_tiff_file tiff;

	f_open_tiff(filename, &img, &tiff);

	fprintf(stderr, "Image size: %d\n", img.size);
	fprintf(stderr, "Image data addr: 0x%08X\n", img.data);

	if(img.data)
		for(uint32_t i = 0; i < 16; i++)
			fprintf(stderr, "\timg.data[%d] = %d\n", i, img.data[i]);

	if(tiff.tiff_data)
	{
		fprintf(stderr, "Tiff file name: %s\n", tiff.filename);
		fprintf(stderr, "Read status: Ok! [tiff data poiner = 0x%08X]\n", tiff.tiff_data);
	}
/*
	if(img.data && tiff.tiff_data)
	{

		for(uint32_t i = 0; i < img.size; i++)
		{
			img.data[i] = 255 - img.data[i];
		}
		f_save_tiff("invert_baboon.tiff", &tiff, &img);
	}
*/
	if(!img.data || !tiff.tiff_data)
	{

		f_close_image(&img);
		f_close_tiff(&tiff);

		return -1;
	}

	uint8_t * tmp_buf;
	uint32_t tmp_buf_size;
	tmp_buf = (uint8_t *)malloc(sizeof(uint8_t)*img.size);
	if(!tmp_buf)
	{
		fprintf(stderr, "Error malloc for tmp_buf [size: %d bytes]\n", sizeof(uint8_t)*img.size);
		f_close_image(&img);
		f_close_tiff(&tiff);

		return -1;
	}
	tmp_buf_size = img.size;

	uint32_t kernel_size = 3;
	int32_t kernel_coeff = 9;
	int32_t kernel_data[ 3 * 3 ] = {
		1, 1, 1,
		1, 1, 1,
		1, 1, 1
	};

	f_convolution_2(img.data, tmp_buf, img.w, img.h, kernel_data, kernel_size, kernel_coeff);

	if(tmp_buf)
		f_save_tiff_2("convolution_baboon.tiff", &tiff, tmp_buf, tmp_buf_size);

/*	if(tmp_buf)
	{
		memcpy((void *)(img.data), (void *)(tmp_buf), tmp_buf_size);
		free(tmp_buf);
	}

	f_save_tiff("convolution_baboon.tiff", &tiff, &img);
*/

	if(tmp_buf)
		free(tmp_buf);

	f_close_image(&img);
	f_close_tiff(&tiff);

	return 0;

}
