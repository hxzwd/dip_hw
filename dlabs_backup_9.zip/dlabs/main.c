

#include "proc.h"


#define DEBUG		1
#define DEBUG_NLM 	1
#define DEBUG_RF	1

#undef DEBUG_NLM
#undef DEBUG_RF
#undef DEBUG

#define NLM_MAIN	1
#undef NLM_MAIN


#define BIN_IMG		1
//#undef BIN_IMG


#include "time.h"

void generate_normal_noise(int8_t * noise, uint32_t buffer_size, double mean, double std)
{
	srand(time(NULL));

	double epsilon = 0.000000000f;
	double x, y;
	double z, z0, z1;
	double s;

	for(uint32_t i = 0; i < buffer_size; i++)
	{
		x = (double)(rand() / RAND_MAX) * 2.0 - 1.0;
		y = (double)(rand() / RAND_MAX) * 2.0 - 1.0;
		s = x * x  + y * y;
		if(abs(s - 0.0 - epsilon) > 0.0 && abs(s - 1.0) <= epsilon)
		{
			z0 = x * sqrt(-2.0f * log(s) / s);
			z1 = y * sqrt(-2.0f * log(s) / s);
			z = mean + z0 * std;
			noise[i] = (int8_t)(z);
		}
		else
		{
			i--;
			continue;
		}
	}

}


void debug_print(struct st_image * img, uint32_t row_len, uint32_t columns_num)
{

	for(uint32_t j = 0; j < columns_num; j++)
	{
		for(uint32_t i = 0; i < row_len; i++)
		{
			fprintf(stderr, "%03d ", img->data[j * img->w + i]);
		}
	fprintf(stderr, "\n");
	}

}

int32_t compare_func(uint8_t * i, uint8_t * j)
{
	return *i - *j;
}

void f_rang_filter(uint8_t * src_data, uint8_t * res_data, uint32_t w, uint32_t h, int32_t * kernel_data, uint32_t kernel_size, int32_t kernel_coeff)
{

	if(!kernel_coeff)
		kernel_coeff = 1;

	uint32_t half_size = kernel_size / 2;
	memcpy(res_data, src_data, sizeof(uint8_t) * w *  h);

	uint32_t sort_buf_size;
	uint8_t * sort_buf;

	sort_buf = NULL;
	sort_buf_size = 0;

	for(uint32_t i = 0; i < kernel_size * kernel_size; i++)
	{
		sort_buf_size += kernel_data[i];
	}

	sort_buf = (uint8_t *)malloc(sizeof(uint8_t) * sort_buf_size);

	if(!sort_buf)
	{
		fprintf(stderr, "In f_rang_filter allocation memory error: requested size %d bytes\n", sizeof(uint8_t) * sort_buf_size);
		return;
	}

#ifdef DEBUG_RF
	uint32_t debug_counter;
	uint32_t debug_counter_limit;
	debug_counter = 0;
	debug_counter_limit = 5;
#endif

	for(uint32_t y = half_size; y < h - half_size; ++y)
	{
		for(uint32_t x = half_size; x < w - half_size; ++x)
		{
			uint32_t * pk = kernel_data;
			uint8_t * ps = &(src_data[(y - half_size) * w + x - half_size]);
			int32_t conv_sum = 0;
			uint32_t sort_buf_counter = 0;

			for(uint32_t v = 0; v < kernel_size; ++v)
			{
				for(uint32_t u = 0; u < kernel_size; u++)
				{
					if(pk[u] == 0)
					{
						continue;
					} else if(pk[u] > 0)
					{
						for(uint32_t i = 0; i < pk[u]; i++)
						{
							sort_buf[sort_buf_counter++] = ps[u];
						}
					}
					//conv_sum += ps[u] * pk[u];
				}
				pk += kernel_size;
				ps += w;
			}
			qsort(sort_buf, sort_buf_size, sizeof(uint8_t), (int32_t (*)(uint8_t *, uint8_t *)) compare_func);

		#ifdef DEBUG_RF
			fprintf(stderr, "debug_counter = %d [debug_counter_limit = %d]\n", debug_counter, debug_counter_limit);
			fprintf(stderr, "Sorted array [sort_buf_size = %d ; sort_buf_counter = %d]:\n", sort_buf_size, sort_buf_counter);
			for(uint32_t i = 0; i < sort_buf_size; i++)
			{
				fprintf(stderr, "%d ", sort_buf[i]);
			}
			fprintf(stderr, "\nMedian value is %d\n", sort_buf[sort_buf_size/2]);
			debug_counter++;
			if(debug_counter >= debug_counter_limit)
			{
				if(sort_buf)
					free(sort_buf);
				return;
			}
		#endif

			/*
			conv_sum = conv_sum / kernel_coeff;
			if(conv_sum > 255)
			{
				conv_sum = 255;
			} else if(conv_sum < 0)
			{
				conv_sum = 0;
			}
			res_data[y*w + x] = (uint8_t)(conv_sum);
			*/
			res_data[y * w + x] = sort_buf[sort_buf_size / 2];
		}
	}

	if(sort_buf)
		free(sort_buf);

}


double block_affinity_func(uint8_t * src_data, uint32_t w, uint32_t h, uint32_t M, uint32_t L, double sigma_param, double h_param, uint32_t r, uint32_t c, uint32_t i, uint32_t j)
{

	uint32_t half_size_x = M/2;
	uint32_t half_size_y = L/2;

	double res;

	res = 0.0f;

	for(uint32_t y = 0; y < L; ++y)
	{
		for(uint32_t x = 0; x < M; ++x)
		{
			uint8_t * p_block_1 = (uint8_t *)(&(src_data[(r - half_size_y + y)*w + c - half_size_x + x]));
			uint8_t * p_block_2 = (uint8_t *)(&(src_data[(r + i - half_size_y + y)*w + c + j - half_size_x + x]));
			int32_t I1 = (int32_t)(*p_block_1);
			int32_t I2 = (int32_t)(*p_block_2);
		#ifdef DEBUG_NLM
			fprintf(stderr, "I1 = %d; I2 = %d\n", I1, I2);
		#endif

			int32_t k = (int32_t)(y) - (int32_t)(half_size_y);
			int32_t n = (int32_t)(x) - (int32_t)(half_size_x);
			res += (I1 - I2)*(I1 - I2)*exp(-(k * k + n * n)/(2.0 * sigma_param * sigma_param));
		}
	}

#ifdef DEBUG_NLM
	fprintf(stderr, "block_affinity_func(): s = %.2f; h = %.2f:\n", sigma_param, h_param);
	fprintf(stderr, "res = %f\n", res);

	res = exp(-res/(h_param * h_param));

	fprintf(stderr, "res = %f\n", res);
#else
	res = exp(-res/(h_param * h_param));
#endif

	return res;

}

void nlm_filter(uint8_t * src_data, uint8_t * res_data, uint32_t w, uint32_t h, uint32_t S, uint32_t K, uint32_t L, uint32_t M, double sigma_param, double h_param)
{

	uint32_t half_size_x = S / 2;
	uint32_t half_size_y = K / 2;
	uint32_t half_size_bx = L / 2;
	uint32_t half_size_by = M / 2;
	memcpy(res_data, src_data, sizeof(uint8_t) * w *  h);

	for(uint32_t y = half_size_y + half_size_by; y < h - half_size_y - half_size_by; ++y)
	{

		for(uint32_t x = half_size_x + half_size_bx; x < w - half_size_x - half_size_bx; ++x)
		{

		#ifdef DEBUG_NLM
			fprintf(stderr, "x = %d; y = %d [data: %d]\n", x, y, src_data[y * w + x]);
		#endif
			double d11 = 0.0;
			double d00 = 0.0;
			int32_t rs;

			for(uint32_t v = y - half_size_y; v < y + half_size_y; ++v)
			{
				for(uint32_t u = x - half_size_x; u < x + half_size_x; ++u)
				{


					double d0;
					double d1;
					d0 = block_affinity_func(src_data, w, h, M, L, sigma_param, h_param, y, x, v - y, u - x);
					d1 = (double)(src_data[v * w + u])*d0;
					d00 += d0;
					d11 += d1;
				#ifdef DEBUG_NLM
					fprintf(stderr, "u = %d; v = %d [data: %d] [d0: %f] [d1: %f]\n", u, v, src_data[v * w + u], d0, d1);
				#endif

				}
			}

			rs = (int32_t)(d11 / d00);
		#ifdef DEBUG_NLM
			fprintf(stderr, "rs = %d; d11 = %f; d00 = %f\n", rs, d11, d00);
		#endif
			if(rs > 255)
			{
				rs = 255;
			} else if(rs < 0)
			{
				rs = 0;
			}

			res_data[y * w + x] = (uint8_t)(rs);
		#ifdef DEBUG_NLM
			break;
		#endif
		}
	#ifdef DEBUG_NLM
		break;
	#endif
	}

}



int32_t debug_main(int32_t argc, char **argv)
{

	char *filename = "data/noise_baboon.tiff";
	struct st_image img;
	struct st_tiff_file tiff;

	f_open_tiff(filename, &img, &tiff);

	fprintf(stderr, "Image size: %d\n", img.size);
	fprintf(stderr, "Image data addr: 0x%08X\n", img.data);


	if(tiff.tiff_data)
	{
		fprintf(stderr, "Tiff file name: %s\n", tiff.filename);
		fprintf(stderr, "Read status: Ok! [tiff data poiner = 0x%08X]\n", tiff.tiff_data);
	}

	if(!img.data || !tiff.tiff_data)
	{

		f_close_image(&img);
		f_close_tiff(&tiff);

		return -1;
	}



	uint8_t * tmp_buf;
	uint32_t tmp_buf_size;
	tmp_buf = (uint8_t *)malloc(sizeof(uint8_t)*img.size);
	if(!tmp_buf)
	{
		fprintf(stderr, "Error malloc for tmp_buf [size: %d bytes]\n", sizeof(uint8_t)*img.size);
		f_close_image(&img);
		f_close_tiff(&tiff);

		return -1;
	}
	tmp_buf_size = img.size;

	uint32_t kernel_size = 3;
	int32_t kernel_coeff = 1;
	int32_t kernel_data[ 3 * 3 ] = {
		0, 2, 0,
		2, 1, 2,
		0, 2, 0
	};

	f_rang_filter(img.data, tmp_buf, img.w, img.h, kernel_data, kernel_size, kernel_coeff);

	if(tmp_buf)
		f_save_tiff_2("rang_filter_noise_baboon.tiff", &tiff, tmp_buf, tmp_buf_size);


	if(tmp_buf)
		free(tmp_buf);

	f_close_image(&img);
	f_close_tiff(&tiff);

	return 0;



	uint8_t * src_data;
	uint8_t * res_data;
	uint32_t w, h, S, K, L, M;
	double sigma_param, h_param;
	src_data = img.data;
	res_data = tmp_buf;
	w = img.w;
	h = img.h;
	S = 7; K = 7;
	L = 3; M = 3;
	sigma_param = 1.0f; h_param = 1.0f;

	debug_print(&img, 25, 10);


	nlm_filter(src_data, res_data, w, h, S, K, L, M, sigma_param, h_param);
	if(tmp_buf)
		f_save_tiff_2("nlm_filter_noise_baboon.tiff", &tiff, tmp_buf, tmp_buf_size);

	debug_print(&img, 25, 10);


	if(tmp_buf)
		free(tmp_buf);

	f_close_image(&img);
	f_close_tiff(&tiff);

	return 0;

}

int32_t open_template_tiff(uint32_t start_row, char * bg_fn, char * in_fn_1, char * in_fn_2, char * out_fn)
{

	char background_filename[128] = { 0 };
	char filename_1[128] = { 0 };
	char filename_2[128] = { 0 };
	char output_filename[128] = { 0 };

	struct st_image background;
	struct st_tiff_file background_tiff;

	struct st_image img1;
	struct st_image img2;
	struct st_tiff_file tiff1;
	struct st_tiff_file tiff2;


	uint8_t * tmp_buf;
	uint32_t tmp_buf_size;

	sprintf(background_filename, "%s", bg_fn);
	sprintf(filename_1, "%s", in_fn_1);
	sprintf(filename_2, "%s", in_fn_2);
	sprintf(output_filename, "%s", out_fn);


	f_open_tiff(background_filename, &background, &background_tiff);

	if(!background.data || !background_tiff.tiff_data)
	{
		f_close_image(&background);
		f_close_tiff(&background_tiff);
		return -1;
	}
	else
	{
		fprintf(stderr, "[background] Status of opening background image (filename .tiff is %s) is ok!...\n", background_filename);
	}

	f_open_tiff(filename_1, &img1, &tiff1);

	if(!img1.data || !tiff1.tiff_data)
	{
		f_close_image(&background);
		f_close_tiff(&background_tiff);
		f_close_image(&img1);
		f_close_tiff(&tiff1);
		return -1;
	}
	else
	{
		fprintf(stderr, "[background] Status of opening first image ( filename .tiff is %s) is ok!...\n", filename_1);
	}


	f_open_tiff(filename_2, &img2, &tiff2);

	if(!img2.data || !tiff2.tiff_data)
	{
		f_close_image(&background);
		f_close_tiff(&background_tiff);
		f_close_image(&img1);
		f_close_tiff(&tiff1);
		f_close_image(&img2);
		f_close_tiff(&tiff2);
		return -1;
	}
	else
	{
		fprintf(stderr, "[background] Status of opening second image ( filename .tiff is %s) is ok!...\n", filename_2);
	}


	tmp_buf = (uint8_t *)malloc(sizeof(uint8_t)*background.size);

	if(!tmp_buf)
	{
		fprintf(stderr, "[background] Error malloc for tmp_buf [size: %d bytes]\n", sizeof(uint8_t)*background.size);
		f_close_image(&background);
		f_close_tiff(&background_tiff);
		f_close_image(&img1);
		f_close_tiff(&tiff1);
		f_close_image(&img2);
		f_close_tiff(&tiff2);
		return -1;
	}

	tmp_buf_size = background.size;
	memcpy(tmp_buf, background.data, background.size);


	uint32_t w_1 = img1.w;
	uint32_t h_1 = img1.h;
	uint32_t w_2 = img2.w;
	uint32_t h_2 = img2.h;
	uint32_t w = w_1;
	uint32_t h = h_1;
	uint32_t w_b = background.w;
	uint32_t h_b = background.h;

	for(uint32_t i = 0 ; i < h ; i++)
	{
		for(uint32_t j = 0 ; j < w ; j++)
		{
			tmp_buf[i * w_b + j + start_row * w_b] = img1.data[i * h + j];
			tmp_buf[i * w_b + j + w + start_row * w_b] = img2.data[i * h + j];
		}
	}

	if(tmp_buf)
	{
		f_save_tiff_2(output_filename, &background_tiff, tmp_buf, tmp_buf_size);
	}

	if(tmp_buf)
	{
		free(tmp_buf);
	}


	f_close_image(&background);
	f_close_tiff(&background_tiff);
	f_close_image(&img1);
	f_close_tiff(&tiff1);
	f_close_image(&img2);
	f_close_tiff(&tiff2);



	return 0;

}


int32_t nlm_main(char * input_fn, char * output_fn, double sigma_param_, double h_param_, uint32_t S_, uint32_t K_, uint32_t L_, uint32_t M_)
{

//	char * filename = "data/noise_baboon.tiff";
	char filename[256] = { 0 };
	char output_filename[256] = { 0 };
	struct st_image img;
	struct st_tiff_file tiff;

	sprintf(filename, "%s", input_fn);
	sprintf(output_filename, "%s", output_fn);

	f_open_tiff(filename, &img, &tiff);

	fprintf(stderr, "Image size: %d\n", img.size);
	fprintf(stderr, "Image data addr: 0x%08X\n", img.data);


	if(tiff.tiff_data)
	{
		fprintf(stderr, "Tiff file name: %s\n", tiff.filename);
		fprintf(stderr, "Read status: Ok! [tiff data poiner = 0x%08X]\n", tiff.tiff_data);
	}

	if(!img.data || !tiff.tiff_data)
	{

		f_close_image(&img);
		f_close_tiff(&tiff);

		return -1;
	}



	uint8_t * tmp_buf;
	uint32_t tmp_buf_size;
	tmp_buf = (uint8_t *)malloc(sizeof(uint8_t)*img.size);
	if(!tmp_buf)
	{
		fprintf(stderr, "Error malloc for tmp_buf [size: %d bytes]\n", sizeof(uint8_t)*img.size);
		f_close_image(&img);
		f_close_tiff(&tiff);

		return -1;
	}
	tmp_buf_size = img.size;


	uint8_t * src_data;
	uint8_t * res_data;
	uint32_t w, h, S, K, L, M;
	double sigma_param, h_param;
	src_data = img.data;
	res_data = tmp_buf;
	w = img.w;
	h = img.h;
//	S = 7; K = 7;
//	L = 3; M = 3;
//	sigma_param = 1.0f; h_param = 100.0f;
	sigma_param = sigma_param_;
	h_param = h_param_;
	S = S_;
	K = K_;
	L = L_;
	M = M_;

//	debug_print(&img, 25, 10);


	nlm_filter(src_data, res_data, w, h, S, K, L, M, sigma_param, h_param);

	if(tmp_buf)
	{
//		f_save_tiff_2("nlm_output/baboon_0.tiff", &tiff, tmp_buf, tmp_buf_size);
		f_save_tiff_2(output_filename, &tiff, tmp_buf, tmp_buf_size);
	}

//	debug_print(&img, 25, 10);


	if(tmp_buf)
		free(tmp_buf);

	f_close_image(&img);
	f_close_tiff(&tiff);

	return 0;

}

int32_t combine_images(char * bg_fn, char * out_fn, char * in_fn_1, char * in_fn_2, char * in_fn_3, char * in_fn_4, uint32_t * row_offset)
{

	int32_t return_code;

	uint32_t start_row;

	char filename_1[128] = { 0 };
	char filename_2[128] = { 0 };
	char filename_3[128] = { 0 };
	char filename_4[128] = { 0 };
	char background_filename[128] = { 0 };
	char output_filename[128] = { 0 };

	if(!bg_fn)
	{
		sprintf(background_filename, "%s", "data/template.tiff");
		fprintf(stderr, "[main.c:combine_images()]: bg_fn = %08X (is NULL)\nUse default background file: %s\n", bg_fn, "data/template.tiff");
	}
	else
	{
		sprintf(background_filename, "%s", bg_fn);
		fprintf(stderr, "[main.c:combine_images()]: bg_fn = %08X\nUse backgroundfile: %s\n", bg_fn, background_filename);
	}
	if(!out_fn)
	{
		sprintf(output_filename, "%s", "combined_image.tiff");
		fprintf(stderr, "[main.c:combine_images()]: out_fn = %08X (is NULL)\nUse default output file: %s\n", out_fn, "combined_image.tiff");
	}
	else
	{
		sprintf(output_filename, "%s", out_fn);
		fprintf(stderr, "[main.c:combine_images()]: out_fn = %08X\nUse output file: %s\n", out_fn, output_filename);
	}



	if(!in_fn_1 || !in_fn_2)
	{
		return_code = 0;
		fprintf(stderr, "[main.c:combine_images()]:\nImage 1 = NONE [ptr = %08X (is NULL)]\nImage 2 = NONE [ptr = %08X (is NULL)]\n", in_fn_1, in_fn_2);
		fprintf(stderr, "[main.c:combine_images()] Return with return value : return_code = %d\n", return_code);
		return return_code;
	}

	start_row = 0;
	sprintf(filename_1, "%s", in_fn_1);
	sprintf(filename_2, "%s", in_fn_2);
	return_code = open_template_tiff(start_row, background_filename, filename_1, filename_2, output_filename);

	fprintf(stderr, "[main.c:combine_images()]:\nImage 1 = %s [ptr = %08X]\nImage 2 = %s [ptr = %08X]\n", filename_1, in_fn_1, filename_2, in_fn_2);
	fprintf(stderr, "start_row = %d\n", start_row);

	if(return_code < 0)
	{
		fprintf(stderr, "[main.c:combine_images()] open_template_tiff() function return_code = %d\n", return_code);
		fprintf(stderr, "[main.c:combine_images()]\n\tstart_row = %d\n\tbackground filename = %s\n\t", start_row, background_filename);
		fprintf(stderr, "filename 1 = %s\n\tfilename 2 = %s\n\toutput filename = %s\n", filename_1, filename_2, output_filename);
		fprintf(stderr, "[main.c:combine_images()] Exit with return code : return_code = %d\n", return_code);
		return return_code;
	}



	if(!in_fn_3 && !in_fn_4)
	{
		fprintf(stderr, "[main.c:combine_images()]:\nImage 3 = NONE [ptr = %08X (is NULL)]\nImage 4 = NONE [ptr = %08X (is NULL)]\n", in_fn_3, in_fn_4);
		fprintf(stderr, "[main.c:combine_images()] Return with return value : return_code = %d\n", return_code);
		return return_code;

	} else if(!in_fn_3 && in_fn_4)
	{
		fprintf(stderr, "[main.c:combine_images()]:\nImage 3 = NONE [ptr = %08X (is NULL)]\nImage 4 = %s [ptr = %08X]\n", in_fn_3, in_fn_4, in_fn_4);
		fprintf(stderr, "[main.c:combine_images()]: Use Image 4 instead Image 3:\n");
		in_fn_3 = in_fn_4;


	} else if(in_fn_3 && !in_fn_4)
	{
		fprintf(stderr, "[main.c:combine_images()]:\nImage 3 = %s [ptr = %08X]\nImage 4 = NONE [ptr = %08X (is NULL)]\n", in_fn_3, in_fn_3, in_fn_4);
		fprintf(stderr, "[main.c:combine_images()]: Use Image 3 instead Image 4:\n");
		in_fn_4 = in_fn_3;

	}


	sprintf(filename_3, "%s", in_fn_3);
	sprintf(filename_4, "%s", in_fn_4);
	fprintf(stderr, "[main.c:combine_images()]:\nImage 3 = NONE [ptr = %08X (is NULL)]\nImage 4 = %s [ptr = %08X]\n", filename_3, in_fn_3, filename_4, in_fn_4);


	if(!row_offset)
	{
		start_row = 512;
		fprintf(stderr, "row_offset = %08X (is NULL)\n", row_offset);
		fprintf(stderr, "start_row = %d (using default value : 512)\n", start_row);

	}
	else
	{
		start_row = *row_offset;
		fprintf(stderr, "row_offset = %08X (not NULL) [value = %d]\n", row_offset, *row_offset);
		fprintf(stderr, "start_row = %d\n", start_row);

	}

	return_code = open_template_tiff(start_row, output_filename, filename_3, filename_4, output_filename);
	if(return_code < 0)
	{
		fprintf(stderr, "[main.c:combine_images()] open_template_tiff() function return_code = %d\n", return_code);
		fprintf(stderr, "[main.c:combine_images()]\n\tstart_row = %d\n\tbackground filename = %s\n\t", start_row, output_filename);
		fprintf(stderr, "filename 3 = %s\n\tfilename 4 = %s\n\toutput filename = %s\n", filename_3, filename_4, output_filename);
		fprintf(stderr, "[main.c:combine_images()] Exit with return code : return_code = %d\n", return_code);
		return return_code;
	}

	return return_code;
}


int32_t combine_main(int32_t argc, char **argv)
{

	char * p;

	char filename_1[128] = { 0 };
	char filename_2[128] = { 0 };
	char filename_3[128] = { 0 };
	char filename_4[128] = { 0 };
	char background_filename[128] = { 0 };
	char output_filename[128] = { 0 };

	int32_t result;

	char * bg_fn = NULL;
	char * out_fn = NULL;
	char * in_fn_1 = NULL;
	char * in_fn_2 = NULL;
	char * in_fn_3 = NULL;
	char * in_fn_4 = NULL;
	uint32_t * row_offset = NULL;
	uint32_t start_row;

	for(uint32_t i = 1 ; i < argc ; i++)
	{
		if(( p = strstr(argv[i], "--f1=")) != NULL)
		{
			p = strstr(argv[i], "=") + 1;
			sprintf(filename_1, "%s", p);
			in_fn_1 = filename_1;

		} else if(( p = strstr(argv[i], "--f2=")) != NULL)
		{
			p = strstr(argv[i], "=") + 1;
			sprintf(filename_2, "%s", p);
			in_fn_2 = filename_2;

		} else if(( p = strstr(argv[i], "--f3=")) != NULL)
		{
			p = strstr(argv[i], "=") + 1;
			sprintf(filename_3, "%s", p);
			in_fn_3 = filename_3;

		} else if(( p = strstr(argv[i], "--f4=")) != NULL)
		{
			p = strstr(argv[i], "=") + 1;
			sprintf(filename_4, "%s", p);
			in_fn_4 = filename_4;

		} else if(( p = strstr(argv[i], "--out=")) != NULL)
		{
			p = strstr(argv[i], "=") + 1;
			sprintf(output_filename, "%s", p);
			out_fn = output_filename;

		} else if(( p = strstr(argv[i], "--bg=")) != NULL)
		{
			p = strstr(argv[i], "=") + 1;
			sprintf(background_filename, "%s", p);
			bg_fn = background_filename;

		} else if(( p = strstr(argv[i], "--off=")) != NULL)
		{
			p = strstr(argv[i], "=") + 1;
			start_row = atoi(p);
			row_offset = &start_row;
		} else if(( p = strstr(argv[i], "--help")) != NULL)
		{
		//	fprintf(stderr, "usage: %s --f1=<path to file 1> --f2=<path to file 2> [OPTIONAL PARAMETERS]\n", argv[0]);
			fprintf(stderr, "usage: %s [OPTIONS]\n", argv[0]);
			return 0;
		} else if(( p = strstr(argv[i], "--default")) != NULL)
		{
			sprintf(filename_1, "%s", "nlm_output/baboon_1.tiff");
			sprintf(filename_2, "%s", "nlm_output/baboon_2.tiff");
			sprintf(filename_3, "%s", "nlm_output/baboon_0.tiff");
			sprintf(filename_4, "%s", "nlm_output/noise_baboon.tiff");
			sprintf(background_filename, "%s", "data/template.tiff");
			sprintf(output_filename, "%s", "combine_image.tiff");
			row_offset = NULL;
			in_fn_1 = filename_1;
			in_fn_2 = filename_2;
			in_fn_3 = filename_3;
			in_fn_4 = filename_4;
			bg_fn = background_filename;
			out_fn = output_filename;
		}

	}
/*
	char * filename_1 = "nlm_output/baboon_1.tiff";
	char * filename_2 = "nlm_output/baboon_2.tiff";
	char * filename_3 = "nlm_output/baboon_0.tiff";
	char * filename_4 = "nlm_output/noise_baboon.tiff";
	char * background_filename = "data/template.tiff";
	char * output_filename = "combine_image.tiff";
*/



	result = combine_images(bg_fn, out_fn, in_fn_1, in_fn_2, in_fn_3, in_fn_4, row_offset);

	return result;

}


int32_t func_otsu_threshold(uint8_t * src_data, uint32_t data_size)
{
	uint8_t image_hist[256] = { 0 };
	uint32_t image_hist_size;
	int32_t m;
	int32_t n;
	double max_sigma;
	int32_t threshold;
	int32_t alpha_1;
	int32_t beta_1;

	image_hist_size = 256;

	for(uint32_t i = 0; i < data_size; i++)
	{
		image_hist[src_data[i]]++;
	}

	m = 0;
	n = 0;

	for(uint32_t i = 0; i < image_hist_size; i++)
	{
		n += image_hist[i];
		m += i * image_hist[i];
	}

	max_sigma = -1.0f;
	threshold = 0;
	alpha_1 = 0;
	beta_1 = 0;

	for(uint32_t i = 0; i < image_hist_size; i++)
	{
		alpha_1 += i * image_hist[i];
		beta_1 += image_hist[i];

		double w_1;
		double average;
		double sigma;

		w_1 = (double)(beta_1)/(double)(n);
		average = (double)(alpha_1)/(double)(beta_1) - (double)(m - alpha_1)/(double)(n - beta_1);

		sigma = w_1 * (1.0f - w_1) * average * average;

		if(sigma > max_sigma)
		{
			max_sigma = sigma;
			threshold = i;
		}

	}

	return threshold;

}

void func_binarize_image(uint8_t * src_data, uint8_t * out_data, uint32_t data_size, int32_t threshold)
{

	for(uint32_t i = 0; i < data_size; i++)
	{
		if(src_data[i] >= threshold)
		{
			out_data[i] = 0;
		}
		else
		{
			out_data[i] = 255;
		}
	}

}

int32_t func_get_neigh(uint8_t * src_data, uint8_t * map_data, uint32_t data_size, uint32_t w, uint32_t h, uint32_t i)
{
	int32_t buffer[4] = { 0 };
	int32_t map_buffer[4] = { 0 };

	int32_t x;
	int32_t y;

	int32_t obj_label;

	x = i % w;
	y = i / w;
	obj_label = 0;


	if(x > 0)
	{
		buffer[0] = src_data[i - 1];
		map_buffer[0] = map_data[i - 1];
	}
	if(x < w - 1)
	{
		buffer[2] = src_data[i + 1];
		map_buffer[2] = map_data[i + 1];
	}
	if(y > 0)
	{
		buffer[1] = src_data[i - w];
		map_buffer[1] = map_data[i - w];
	}
	if(y < h - 1)
	{
		buffer[3] = src_data[i + w];
		map_buffer[3] = map_data[i + w];
	}

	for(uint32_t j = 0; j < 4; j++)
	{
		if(buffer[j] == 255 && map_buffer[j] > 0)
		{
			obj_label = (uint8_t)(map_buffer[j]);
			return obj_label;
		}
	}

	return obj_label;

}

uint32_t func_select_objects_4(uint8_t * src_data, uint8_t * obj_map, uint32_t data_size, uint32_t w, uint32_t h)
{

	uint32_t object_counter;
	object_counter = 0;

	for(uint32_t i = 0; i < data_size; i++)
	{
		if(src_data[i] == 0)
		{
			continue;
		}

		if(obj_map[i] > 0)
		{
			continue;
		}

		int32_t obj_label;
		obj_label = func_get_neigh(src_data, obj_map, data_size, w, h, i);

		if(obj_label == 0)
		{
			object_counter++;
			obj_map[i] = object_counter;
		}
		else
		{
			obj_map[i] = (uint8_t)(obj_label);
		}

	}

	return object_counter;

}

int32_t func_select_objects_4_other(uint8_t * src_data, uint8_t * obj_map, uint32_t data_size, uint32_t w, uint32_t h)
{

	int32_t o_counter;
	int32_t o_counter_2;

	uint32_t x_max;
	uint32_t y_max;

	int32_t B;
	int32_t A;
	int32_t C;

	x_max = w;
	y_max = h;

	o_counter = 0;
	o_counter_2 = 0;

	memcpy(obj_map, src_data, data_size);

	for(uint32_t y = 0; y < y_max; y++)
	{
		for(uint32_t x = 0; x < x_max; x++)
		{
			int32_t kn;
			int32_t km;
			kn = x - 1;
			if(kn < 0)
			{
				kn = 0;
				B = 0;
			}
			else
			{
				B = obj_map[ y * w + kn ];

			}

			km = y - 1;
			if(km < 0)
			{
				km = 0;
				C = 0;
			}
			else
			{
				C = obj_map[ km * w + x ];
			}

			A = obj_map[ y * w + x ];

			if(A == 0)
			{

			}
			else
			{
				if(B == 0 && C == 0)
				{
					o_counter += 1;
					o_counter_2++;
					obj_map[ y * w + x ] = o_counter;
				}
				else
				{
					if(B != 0 && C == 0)
					{
						obj_map[ y * w + x ] = B;
					}
					else
					{
						if(B == 0 && C != 0)
						{
							obj_map[ y * w + x ] = C;
						}
						else
						{
							if(B != 0 && C != 0)
							{
								if(B == C)
								{
									obj_map[ y * w + x ] = B;
								}
								else
								{
									obj_map[ y * w + x ] = B;
									o_counter_2--;
									for(uint32_t ii = 0; ii < data_size; ii++)
									{
										if(obj_map[ii] == C)
										{
											obj_map[ii] = B;
										}
									}
								}
							}
						}
					}
				}
			}

		}
	}


	return o_counter_2;

}


int32_t func_select_objects_4_other_other(uint8_t * src_data, int32_t * obj_map, uint32_t data_size, uint32_t w, uint32_t h)
{

	int32_t o_counter;
	int32_t o_counter_2;

	uint32_t x_max;
	uint32_t y_max;

	int32_t B;
	int32_t A;
	int32_t C;

	x_max = w;
	y_max = h;

	o_counter = 0;
	o_counter_2 = 0;


	for(uint32_t y = 0; y < y_max; y++)
	{
		for(uint32_t x = 0; x < x_max; x++)
		{
			int32_t kn;
			int32_t km;
			kn = x - 1;
			if(kn < 0)
			{
				kn = 0;
				B = 0;
			}
			else
			{
				B = obj_map[ y * w + kn ];

			}

			km = y - 1;
			if(km < 0)
			{
				km = 0;
				C = 0;
			}
			else
			{
				C = obj_map[ km * w + x ];
			}

			A = obj_map[ y * w + x ];

			if(A == 0)
			{

			}
			else
			{
				if(B == 0 && C == 0)
				{
					o_counter += 1;
					o_counter_2++;
					obj_map[ y * w + x ] = o_counter;
				}
				else
				{
					if(B != 0 && C == 0)
					{
						obj_map[ y * w + x ] = B;
					}
					else
					{
						if(B == 0 && C != 0)
						{
							obj_map[ y * w + x ] = C;
						}
						else
						{
							if(B != 0 && C != 0)
							{
								if(B == C)
								{
									obj_map[ y * w + x ] = B;
								}
								else
								{
									obj_map[ y * w + x ] = B;
									o_counter_2--;
									for(uint32_t ii = 0; ii < data_size; ii++)
									{
										if(obj_map[ii] == C)
										{
											obj_map[ii] = B;
										}
									}
								}
							}
						}
					}
				}
			}

		}
	}


	return o_counter_2;

}

int32_t func_in_buffer(int32_t value, int32_t * buffer, uint32_t buffer_size)
{
	if(value == 0)
	{
		return 0;
	}
	for(uint32_t i = 0; i < buffer_size; i++)
	{
		if(buffer[i] == 0)
		{
			break;
		}
		if(buffer[i] == value)
		{
			return 1;
		}
	}
	return 0;
}

struct st_moments
{
	uint64_t m00;
	uint64_t m01;
	uint64_t m10;
	double mu20;
	double mu02;
	double mu11;

};

void func_print_moments(struct st_moments * data)
{
	fprintf(stderr, "----------------------------------------------\n");
	fprintf(stderr, "m00 = %d\n", data->m00);
	fprintf(stderr, "m01 = %d\n", data->m01);
	fprintf(stderr, "m10 = %d\n", data->m10);
	fprintf(stderr, "mu20 = %f\n", data->mu20);
	fprintf(stderr, "mu02 = %f\n", data->mu02);
	fprintf(stderr, "mu11 = %f\n", data->mu11);
	fprintf(stderr, "----------------------------------------------\n");
}

void func_calc_momemnts(uint8_t * src_data, int32_t * label_map, uint32_t w, uint32_t h, int32_t label, struct st_moments * result)
{
	uint64_t m00;
	uint64_t m01;
	uint64_t m10;

	double mu20;
	double mu02;
	double mu11;

	m00 = 0;
	m01 = 0;
	m10 = 0;

	mu20 = 0.0f;
	mu02 = 0.0f;
	mu11 = 0.0f;

	for(uint32_t y = 0; y < h; y++)
	{
		for(uint32_t x = 0; x < w; x++)
		{
			if(label_map[ y * w + x ] == label)
			{
				m00 += src_data[ y * w + x];
				m10 += (x + 1) * src_data[ y * w + x ];
				m01 += (y + 1) * src_data[ y * w + x ];
			}
		}
	}

	result->m00 = m00;
	result->m01 = m01;
	result->m10 = m10;

	double xc;
	double yc;

	xc = (double)(m10)/(double)(m00);
	yc = (double)(m01)/(double)(m00);

	for(uint32_t y = 0; y < h; y++)
	{
		for(uint32_t x = 0; x < w; x++)
		{
			if(label_map[ y * w + x ] == label)
			{
				mu20 += (double)(((x + 1) - xc) * ((x + 1) - xc) * src_data[ y * w + x]);
				mu02 += (double)(((y + 1) - yc) * ((y + 1) - yc) * src_data[ y * w + x ]);
				mu11 += (double)(((x + 1) - xc) * ((y + 1) - yc) * src_data[ y * w + x ]);
			}
		}
	}

	result->mu20 = mu20;
	result->mu02 = mu02;
	result->mu11 = mu11;

	return;

}


int32_t bin_img_main(int32_t argc, char **argv)
{
	fprintf(stderr, "[bin_img_main()] Lab 7 task!\nOk!...\n");


//	char *filename = "data/noise_baboon.tiff";
	char * filename = "data/bagira.tiff";
	struct st_image img;
	struct st_tiff_file tiff;

	f_open_tiff(filename, &img, &tiff);

	fprintf(stderr, "Image size: %d\n", img.size);
	fprintf(stderr, "Image data addr: 0x%08X\n", img.data);


	if(tiff.tiff_data)
	{
		fprintf(stderr, "Tiff file name: %s\n", tiff.filename);
		fprintf(stderr, "Read status: Ok! [tiff data poiner = 0x%08X]\n", tiff.tiff_data);
	}

	if(!img.data || !tiff.tiff_data)
	{

		f_close_image(&img);
		f_close_tiff(&tiff);

		return -1;
	}



	uint8_t * tmp_buf;
	uint32_t tmp_buf_size;
	tmp_buf = (uint8_t *)malloc(sizeof(uint8_t)*img.size);
	if(!tmp_buf)
	{
		fprintf(stderr, "Error malloc for tmp_buf [size: %d bytes]\n", sizeof(uint8_t)*img.size);
		f_close_image(&img);
		f_close_tiff(&tiff);

		return -1;
	}
	tmp_buf_size = img.size;

	memcpy(tmp_buf, img.data, tmp_buf_size);

	int32_t threshold;

	threshold = func_otsu_threshold(tmp_buf, tmp_buf_size);

	threshold = 60;

	func_binarize_image(img.data, tmp_buf, tmp_buf_size, threshold);

	uint8_t * tmp_buf_2 = (uint8_t *)(malloc(sizeof(uint8_t) * img.size));
	memset(tmp_buf_2, 0, img.size);

	int32_t * tmp_buf_3 = (int32_t *)(malloc(sizeof(int32_t) * img.size));

	for(uint32_t i = 0; i < img.size; i++)
	{
		tmp_buf_3[i] = (int32_t)(tmp_buf[i]);
	}

//	uint32_t obj_num = func_select_objects_4(tmp_buf, tmp_buf_2, img.size, img.w, img.h);
//	fprintf(stderr, "OBJ_NUM = %d\n", obj_num);

	int32_t obj_num_other = func_select_objects_4_other(tmp_buf, tmp_buf_2, img.size, img.w, img.h);
	fprintf(stderr, "OBJ_NUM_OTHER = %d\n", obj_num_other);

	int32_t obj_num_other_other = func_select_objects_4_other_other(tmp_buf, tmp_buf_3, img.size, img.w, img.h);
	fprintf(stderr, "OBJ_NUM_OTHER_OTHER = %d\n", obj_num_other_other);

	int32_t labels_buffer[4096] = { 0 };
	uint32_t labels_counter;
	uint32_t labels_buffer_size;
	labels_counter = 0;
	labels_buffer_size = 4096;

	for(uint32_t i = 0; i < img.size; i++)
	{
		if(tmp_buf_3[i] == 0)
		{
			continue;
		}
		if(!func_in_buffer(tmp_buf_3[i], labels_buffer, labels_buffer_size))
		{
			labels_buffer[labels_counter++] = tmp_buf_3[i];
		}
		else
		{
			continue;
		}
	}

	fprintf(stderr, "labels_counter = %d\n", labels_counter);
	for(uint32_t i = 0; i < labels_counter; i++)
	{
		if(i % 2 == 0 && i != 0)
		{
			fprintf(stderr, "\n");
		}
		fprintf(stderr, "labels_buffer[%04d] = %04d\t", i, labels_buffer[i]);

	}
	fprintf(stderr, "\n");

	for(uint32_t i = 0; i < 3; i++)
	{
		struct st_moments data;
		fprintf(stderr, "Calc moments for label = %d\n", labels_buffer[i]);
		func_calc_momemnts(img.data, tmp_buf_3, img.w, img.h, labels_buffer[i], &data);
		func_print_moments(&data);
	}

	if(tmp_buf_3)
	{
		free(tmp_buf_3);
	}


	if(tmp_buf)
	{
//		f_save_tiff_2("binarized_noise_baboon.tiff", &tiff, tmp_buf, tmp_buf_size);
		f_save_tiff_2("binarized_bagira.tiff", &tiff, tmp_buf, tmp_buf_size);
	}

	if(tmp_buf_2)
	{
//		f_save_tiff_2("binarized_noise_baboon_map.tiff", &tiff, tmp_buf_2, tmp_buf_size);
		f_save_tiff_2("binarized_bagira_map.tiff", &tiff, tmp_buf_2, tmp_buf_size);
		free(tmp_buf_2);
	}

	if(tmp_buf)
	{
		free(tmp_buf);
	}

	f_close_image(&img);
	f_close_tiff(&tiff);

	return 0;



	uint8_t * src_data;
	uint8_t * res_data;
	uint32_t w, h, S, K, L, M;
	double sigma_param, h_param;
	src_data = img.data;
	res_data = tmp_buf;
	w = img.w;
	h = img.h;
	S = 7; K = 7;
	L = 3; M = 3;
	sigma_param = 1.0f; h_param = 1.0f;

	debug_print(&img, 25, 10);


	nlm_filter(src_data, res_data, w, h, S, K, L, M, sigma_param, h_param);
	if(tmp_buf)
		f_save_tiff_2("nlm_filter_noise_baboon.tiff", &tiff, tmp_buf, tmp_buf_size);

	debug_print(&img, 25, 10);


	if(tmp_buf)
		free(tmp_buf);

	f_close_image(&img);
	f_close_tiff(&tiff);

	return 0;


	return 0;

}

int32_t main(int32_t argc, char **argv)
{

#ifdef BIN_IMG

	return bin_img_main(argc, argv);

#endif


#ifdef DEBUG

	return debug_main(argc, argv);

#else

#ifdef NLM_MAIN

	int32_t status;

	char input_fn[256] = { 0 };
	char output_fn[256] = { 0 };

	sprintf(input_fn, "data/noise_baboon.tiff");
	sprintf(output_fn, "nlm_output/default_output_0.tiff");

	double sigma_param;
	double h_param;
	uint32_t S;
	uint32_t K;
	uint32_t L;
	uint32_t M;

	sigma_param = 1.0f;
	h_param = 100.0f;
	S = 7;
	K = 7;
	L = 3;
	M = 3;

	char * arg_value_ptr;


	for(uint32_t i = 1 ; i < argc ; i++)
	{
		if((arg_value_ptr = strstr(argv[i], "--in=")) != NULL)
		{
			arg_value_ptr = strstr(argv[i], "=") + 1;
			sprintf(input_fn, "%s", arg_value_ptr);

		} else if((arg_value_ptr = strstr(argv[i], "--out=")) != NULL)
		{
			arg_value_ptr = strstr(argv[i], "=") + 1;
			sprintf(output_fn, "%s", arg_value_ptr);

		} else if((arg_value_ptr = strstr(argv[i], "--sigma=")) != NULL)
		{
			arg_value_ptr = strstr(argv[i], "=") + 1;
			sigma_param = strtod(arg_value_ptr, NULL);

		} else if((arg_value_ptr = strstr(argv[i], "--h=")) != NULL)
		{
			arg_value_ptr = strstr(argv[i], "=") + 1;
			h_param = strtod(arg_value_ptr, NULL);

		} else if((arg_value_ptr = strstr(argv[i], "--S=")) != NULL)
		{
			arg_value_ptr = strstr(argv[i], "=") + 1;
			S = atoi(arg_value_ptr);

		} else if((arg_value_ptr = strstr(argv[i], "--K=")) != NULL)
		{
			arg_value_ptr = strstr(argv[i], "=") + 1;
			K = atoi(arg_value_ptr);
		} else if((arg_value_ptr = strstr(argv[i], "--L=")) != NULL)
		{
			arg_value_ptr = strstr(argv[i], "=") + 1;
			L = atoi(arg_value_ptr);
		} else if((arg_value_ptr = strstr(argv[i], "--M=")) != NULL)
		{
			arg_value_ptr = strstr(argv[i], "=") + 1;
			M = atoi(arg_value_ptr);
		} else if((arg_value_ptr = strstr(argv[i], "--help")) != NULL)
		{
			fprintf(stderr, "usage: %s [OPTIONS]\n", argv[0]);
			fprintf(stderr, "OPTIONS LIST:\n");
			fprintf(stderr, "\t--in=<path to .tiff file> - input image file\n");
			fprintf(stderr, "\t--out=<path to .tiff file> - output image file\n");
			fprintf(stderr, "\t--sigma=<float> - parameter sigma of nlm-filter\n");
			fprintf(stderr, "\t--h=<float> - parameter h of nlm-filter\n");
			fprintf(stderr, "\t--S=<uint8_t> - width of filter-window\n");
			fprintf(stderr, "\t--K=<uint8_t> - height of filter-window\n");
			fprintf(stderr, "\t--L=<uint8_t> - width of compare block\n");
			fprintf(stderr, "\t--M=<uint8_t> - height of compare block\n");
			fprintf(stderr, "\t--combine - combine .tiff images\n");

			return 0;
		} else if((arg_value_ptr = strstr(argv[i], "--combine")) != NULL)
		{

			return combine_main(argc, argv);

		}


	}


	fprintf(stderr, "[main.c:main()] NLM filter of .tiff image.\n");
	fprintf(stderr, "[main.c:main()] Use %s as input image\n", input_fn);
	fprintf(stderr, "[main.c:main()] Use %s as output image\n", output_fn);
	fprintf(stderr, "[main.c:main()] Parameters of nlm-filter (sigma, h, S, K, L, M):\n");
	fprintf(stderr, "\tsigma = %f\n\th = %f\n\t", sigma_param, h_param);
	fprintf(stderr, "S = %d\n\tK = %d\n\tL = %d\n\tM = %d\n", S, K, L, M);
	fprintf(stderr, "[main.c:main()] Call nlm_main() function...\n");


	status = nlm_main(input_fn, output_fn, sigma_param, h_param, S, K, L, M);

	fprintf(stderr, "[main.c:main()] Status of nlm_main() is %d\n", status);
	fprintf(stderr, "[main.c:main()] Return status = %d\n", status);

	return status;

#else

	int32_t status;

	char filename[128] = { 0 };
	char output[128] = { 0 };
	char paramfile[128] = { 0 };

	if(argc >= 2)
	{
		strcpy(filename, argv[1]);
		if(argc >= 3)
		{
			strcpy(output, argv[2]);
			if(argc >= 4)
			{
				strcpy(paramfile, argv[3]);
			}
		}
	}
	else
	{
		fprintf(stderr, "usage: %s <input file> [<output file> [<param file>]]\n");
		return -1;
	}

	status = proc_image(filename, output, paramfile);

	if(status >= 0)
	{
		fprintf(stderr, "proc_image() status = %d\nOk!\n", status);
		return status;
	}
	else
	{
		fprintf(stderr, "proc_image() status = %d\nError!\n", status);
		return status;
	}


	return 0;

#endif
#endif

}



/*
	int8_t * noise;
	uint32_t noise_size = img.size;
	noise = (int8_t *)malloc(sizeof(int8_t) * noise_size);
	generate_normal_noise(noise, noise_size, 0.0f, 25.0f);
	for(uint32_t i = 0; i < img.size; i++)
	{
		int32_t noised = img.data[i] + noise[i];
		if(noised > 255)
			noised = 255;
		if(noised < 0)
			noised = 0;
		tmp_buf[i] = (uint8_t)(noised);
	}
	f_save_tiff_2("noised_baboon.tiff", &tiff, tmp_buf, tmp_buf_size);

	if(tmp_buf)
		free(tmp_buf);
	if(noise)
		free(noise);

	f_close_image(&img);
	f_close_tiff(&tiff);

	return 0;
*/
